"""브라우저 체험판(GitHub Pages)용 연결 모듈.

Pyodide(브라우저 안 파이썬)에서 서버 없이 같은 API 코드를 실행한다.
- handle(): HTTP 대신 자바스크립트 fetch 가로채기에서 호출
- drain(): 실시간 알림(SSE) 대신, 쌓인 이벤트를 꺼내 화면에 전달
- startup(): 미리 만들어 둔 데모 DB의 날짜를 '지금'으로 옮김
"""
from __future__ import annotations

import datetime as dt
import json
from urllib.parse import parse_qs

from . import api, auth, care, db, events, seed

_queues: dict[int, object] = {}

# 날짜를 옮길 칼럼 (생년월일은 옮기지 않음)
_TIME_COLS = {
    "reservations": ["start_at", "end_at", "checkin_at", "checkout_at", "created_at", "cancelled_at"],
    "booking_failures": ["start_at", "end_at", "created_at"],
    "notifications": ["created_at", "read_at"],
    "messages": ["created_at"],
    "threads": ["created_at"],
    "demand_requests": ["created_at"],
    "spaces": ["updated_at"],
    "hub_plan": ["updated_at"],
    "audit_log": ["created_at"],
}


def _shift(s: str | None, delta: dt.timedelta) -> str | None:
    if not s:
        return s
    try:
        v = dt.datetime.fromisoformat(s) + delta
    except ValueError:
        return s
    return v.isoformat(timespec="minutes" if len(s) <= 16 else "seconds")


def startup(restored: bool) -> str:
    """restored=False면 데모 DB의 시각을 지금으로 옮긴다(30분 단위로 맞춰 예약 칸이 어긋나지 않게)."""
    db.init()
    con = db.connect()
    try:
        if not restored:
            seed_now = db.get_setting(con, "seed_now")
            if seed_now:
                delta = db.now() - dt.datetime.fromisoformat(seed_now)
                step = 30 * 60
                delta = dt.timedelta(seconds=round(delta.total_seconds() / step) * step)
                for table, cols in _TIME_COLS.items():
                    rows = db.rows(con, f"SELECT id, {', '.join(cols)} FROM {table}" if table != "hub_plan"
                                   else f"SELECT slot AS id, {', '.join(cols)} FROM {table}")
                    key = "slot" if table == "hub_plan" else "id"
                    for r in rows:
                        vals = [_shift(r[c], delta) for c in cols]
                        con.execute(f"UPDATE {table} SET {', '.join(c + '=?' for c in cols)} WHERE {key}=?", (*vals, r["id"]))
                db.set_setting(con, "seed_now", db.now_s())
            db.set_setting(con, "demo_today", dt.date.today().isoformat())
            con.execute("DELETE FROM sessions")
            con.commit()
        care.sweep(con)
        return dt.date.today().isoformat()
    finally:
        con.close()


def handle(method: str, path: str, qs: str, body_text: str | None, token: str | None) -> str:
    con = db.connect()
    try:
        user = auth.user_for_token(con, token)
        query = {k: v[0] for k, v in parse_qs(qs or "").items()}
        try:
            body = json.loads(body_text) if body_text else None
        except ValueError:
            return json.dumps({"status": 400, "body": {"error": "JSON 형식 오류"}, "cookie": None}, ensure_ascii=False)
        req = api.Req(method, path, query, body, user, token, con)
        try:
            out, status = api.dispatch(req), 200
        except api.ApiError as e:
            out, status = {"error": e.msg, "code": e.code}, e.status
        except care.BookingError as e:
            out, status = {"error": str(e), "code": e.code}, 400
        return json.dumps({"status": status, "body": out, "cookie": req.set_cookie}, ensure_ascii=False, default=str)
    finally:
        con.close()


def export(path: str, qs: str, token: str | None) -> str:
    con = db.connect()
    try:
        user = auth.user_for_token(con, token)
        if not user or user["role"] != "city":
            return json.dumps({"status": 403})
        query = {k: v[0] for k, v in parse_qs(qs or "").items()}
        req = api.Req("GET", path, query, None, user, token, con)
        name = path.rstrip("/").split("/")[-1][:-4]
        fname, data = api.export_csv(req, name)
        return json.dumps({"status": 200, "filename": fname, "text": data.decode("utf-8")}, ensure_ascii=False)
    finally:
        con.close()


def subscribe(token: str | None) -> int:
    con = db.connect()
    try:
        user = auth.user_for_token(con, token)
    finally:
        con.close()
    if not user:
        return 0
    if user["id"] not in _queues:
        _queues[user["id"]] = events.subscribe(user["id"])
    return user["id"]


def drain(user_id: int) -> str:
    q = _queues.get(user_id)
    out = []
    while q is not None and not q.empty():
        out.append(q.get_nowait())
    return json.dumps(out, ensure_ascii=False)


def sweep() -> None:
    con = db.connect()
    try:
        care.sweep(con)
    finally:
        con.close()


DEMO_PW = seed.DEMO_PW
