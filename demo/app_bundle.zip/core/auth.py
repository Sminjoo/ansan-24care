"""비밀번호 해시와 세션."""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import os
import secrets

from . import db

SESSION_DAYS = 7


def _iterations() -> int:
    # 브라우저 체험판(CARE_STATIC)은 계산이 느려서 반복 횟수를 줄인다(시연용 계정만 있음)
    return 1_000 if os.environ.get("CARE_STATIC") else 120_000


def _pbkdf2_sha256(password: bytes, salt: bytes, iterations: int) -> bytes:
    """hashlib.pbkdf2_hmac이 없는 환경(브라우저 Pyodide)용 PBKDF2-HMAC-SHA256 (RFC 8018, 32바이트)."""
    if hasattr(hashlib, "pbkdf2_hmac"):
        return hashlib.pbkdf2_hmac("sha256", password, salt, iterations)
    mac = hmac.new(password, digestmod=hashlib.sha256)

    def prf(data: bytes) -> bytes:
        m = mac.copy()
        m.update(data)
        return m.digest()

    u = prf(salt + b"\x00\x00\x00\x01")
    out = int.from_bytes(u, "big")
    for _ in range(iterations - 1):
        u = prf(u)
        out ^= int.from_bytes(u, "big")
    return out.to_bytes(32, "big")


def hash_pw(password: str, salt: str | None = None) -> tuple[str, str]:
    salt = salt or secrets.token_hex(16)
    h = _pbkdf2_sha256(password.encode(), bytes.fromhex(salt), _iterations()).hex()
    return h, salt


def verify(password: str, pw_hash: str, salt: str) -> bool:
    return hmac.compare_digest(hash_pw(password, salt)[0], pw_hash)


def create_session(con, user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    exp = (db.now() + dt.timedelta(days=SESSION_DAYS)).isoformat()
    con.execute("INSERT INTO sessions(token,user_id,created_at,expires_at) VALUES(?,?,?,?)", (token, user_id, db.now_s(), exp))
    con.execute("DELETE FROM sessions WHERE expires_at < ?", (db.now_s(),))
    return token


def user_for_token(con, token: str | None) -> dict | None:
    if not token:
        return None
    return db.one(con, """SELECT u.id,u.username,u.role,u.name,u.phone,u.home_dong,u.facility_id,u.demo
                          FROM sessions s JOIN users u ON u.id=s.user_id
                          WHERE s.token=? AND s.expires_at > ?""", (token, db.now_s()))


def drop_session(con, token: str | None) -> None:
    if token:
        con.execute("DELETE FROM sessions WHERE token=?", (token,))
