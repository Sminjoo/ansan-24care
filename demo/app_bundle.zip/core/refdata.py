"""참조 데이터(행정동 경계·코드·주거 중심) 로더."""
from __future__ import annotations

import csv
import json
import math
import random
from functools import lru_cache
from pathlib import Path

from . import geo

APP = Path(__file__).resolve().parents[1]
DATA = APP / "data"
REF = DATA / "reference"
GEOJSON = APP / "static" / "data" / "ansan_dong.geojson"


def read_csv(path: Path) -> list[dict]:
    """CP949(실제 납품 데이터) 또는 UTF-8(공개 데이터) CSV를 읽는다."""
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp949"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ValueError(f"인코딩을 알 수 없음: {path}")
    return list(csv.DictReader(text.splitlines()))


@lru_cache(maxsize=1)
def dongs() -> list[dict]:
    rows = read_csv(REF / "admin_dong.csv")
    anchors = {}
    anchor_path = REF / "residential_anchor.csv"
    if anchor_path.exists():
        anchors = {r["ADMI_NM"]: r for r in read_csv(anchor_path)}
    shapes = {f["properties"]["code"]: f["geometry"] for f in json.loads(GEOJSON.read_text(encoding="utf-8"))["features"]}
    out = []
    for r in rows:
        a = anchors.get(r["ADMI_NM"])
        area = float(r["AREA_KM2"])
        d = {
            "code": r["ADMI_CD"], "code10": r["ADMI_CD10"], "stat_cd": r.get("STAT_CD", ""),
            "name": r["ADMI_NM"], "gu": r["GU_NM"],
            "lat": float(r["CENTER_LAT"]), "lon": float(r["CENTER_LON"]),
            "x": float(r["CENTER_X"]), "y": float(r["CENTER_Y"]), "area": area,
            "res_lat": float(a["RES_LAT"]) if a else float(r["CENTER_LAT"]),
            "res_lon": float(a["RES_LON"]) if a else float(r["CENTER_LON"]),
            # 작은 동은 사실상 균등 분포가 되도록 시그마를 크게 둔다
            "res_sigma": float(a["RES_SIGMA_KM"]) if a else max(0.6, math.sqrt(area)),
            "geometry": shapes[r["ADMI_CD"]],
        }
        out.append(d)
    return out


def dong_by_code() -> dict[str, dict]:
    return {d["code"]: d for d in dongs()}


def dong_by_name() -> dict[str, dict]:
    return {d["name"]: d for d in dongs()}


def locate_dong(lat: float, lon: float) -> dict | None:
    for d in dongs():
        x0, y0, x1, y1 = geo.geometry_bbox(d["geometry"])
        if x0 <= lon <= x1 and y0 <= lat <= y1 and geo.point_in_geometry(lon, lat, d["geometry"]):
            return d
    return None


def sample_point_in_dong(d: dict, rng: random.Random, sigma_scale: float = 0.6) -> tuple[float, float]:
    """주거 중심 근처에서 동 경계 안의 임의 점을 뽑는다."""
    s_km = d["res_sigma"] * sigma_scale
    for _ in range(500):
        lat = d["res_lat"] + rng.gauss(0, s_km / 111.0)
        lon = d["res_lon"] + rng.gauss(0, s_km / 88.3)
        if geo.point_in_geometry(lon, lat, d["geometry"]):
            return round(lat, 6), round(lon, 6)
    return d["res_lat"], d["res_lon"]
