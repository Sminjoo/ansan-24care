"""REST API 라우팅과 핸들러."""
from __future__ import annotations

import csv
import datetime as dt
import io
import json
import re
from collections import Counter, defaultdict

from . import analysis, auth, care, db, refdata
from .holidays import day_type


class ApiError(Exception):
    def __init__(self, status: int, msg: str, code: str = "error"):
        super().__init__(msg)
        self.status, self.msg, self.code = status, msg, code


class Req:
    def __init__(self, method, path, query, body, user, token, con):
        self.method, self.path, self.query, self.body = method, path, query, body
        self.user, self.token, self.con = user, token, con
        self.params: dict = {}
        self.set_cookie: str | None = None

    def q(self, key, default=None, cast=str):
        v = self.query.get(key)
        if v is None or v == "":
            return default
        try:
            return cast(v)
        except (TypeError, ValueError):
            raise ApiError(400, f"'{key}' 값이 올바르지 않습니다.")

    def b(self, key, default=None):
        return (self.body or {}).get(key, default)


ROUTES: list[tuple[str, re.Pattern, object, tuple]] = []


def route(method: str, pattern: str, roles: tuple = ()):
    rx = re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", pattern) + "$")

    def deco(fn):
        ROUTES.append((method, rx, fn, roles))
        return fn
    return deco


def dispatch(req: Req):
    for method, rx, fn, roles in ROUTES:
        if method != req.method:
            continue
        m = rx.match(req.path)
        if not m:
            continue
        if roles:
            if not req.user:
                raise ApiError(401, "로그인이 필요합니다.", "auth")
            if req.user["role"] not in roles:
                raise ApiError(403, "권한이 없습니다.", "forbidden")
        req.params = m.groupdict()
        return fn(req)
    raise ApiError(404, "없는 주소입니다.", "notfound")


def _int(v, name="id") -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        raise ApiError(400, f"{name} 값이 올바르지 않습니다.")


def _date(s: str | None) -> dt.date:
    if not s:
        return dt.date.today()
    try:
        return dt.date.fromisoformat(s)
    except ValueError:
        raise ApiError(400, "날짜 형식은 YYYY-MM-DD 입니다.")


# ── 공통 ────────────────────────────────────────────────
@route("GET", "/api/health")
def health(req):
    return {"ok": True, "time": db.now_s()}


@route("GET", "/api/about")
def about(req):
    b = analysis.base()
    return {"virtual": b["virtual"], "built_at": b["built_at"], "today": dt.date.today().isoformat(),
            "day_type": day_type(dt.date.today()), "now": db.now_s()}


@route("POST", "/api/login")
def login(req):
    u = db.one(req.con, "SELECT * FROM users WHERE username=?", ((req.b("username") or "").strip(),))
    if not u or not auth.verify(req.b("password") or "", u["pw_hash"], u["salt"]):
        raise ApiError(401, "아이디 또는 비밀번호가 맞지 않습니다.", "auth")
    token = auth.create_session(req.con, u["id"])
    req.con.commit()
    req.set_cookie = token
    return {"user": _me(req.con, u["id"])}


@route("POST", "/api/logout")
def logout(req):
    auth.drop_session(req.con, req.token)
    req.con.commit()
    req.set_cookie = ""
    return {"ok": True}


@route("POST", "/api/register")
def register(req):
    username = (req.b("username") or "").strip()
    pw = req.b("password") or ""
    name = (req.b("name") or "").strip()
    home = req.b("home_dong") or None
    if not re.fullmatch(r"[A-Za-z0-9_]{4,20}", username):
        raise ApiError(400, "아이디는 영문·숫자 4~20자입니다.")
    if len(pw) < 8:
        raise ApiError(400, "비밀번호는 8자 이상입니다.")
    if not name:
        raise ApiError(400, "이름을 입력해 주세요.")
    if home and home not in refdata.dong_by_code():
        raise ApiError(400, "사는 동을 다시 골라 주세요.")
    if db.one(req.con, "SELECT 1 FROM users WHERE username=?", (username,)):
        raise ApiError(409, "이미 쓰는 아이디입니다.")
    h, s = auth.hash_pw(pw)
    uid = req.con.execute("""INSERT INTO users(username,pw_hash,salt,role,name,phone,home_dong,created_at)
                             VALUES(?,?,?,'parent',?,?,?,?)""", (username, h, s, name, req.b("phone") or "", home, db.now_s())).lastrowid
    token = auth.create_session(req.con, uid)
    req.con.commit()
    req.set_cookie = token
    return {"user": _me(req.con, uid)}


def _me(con, uid: int) -> dict:
    u = db.one(con, "SELECT id,username,role,name,phone,home_dong,facility_id,demo FROM users WHERE id=?", (uid,))
    if u["home_dong"]:
        d = refdata.dong_by_code().get(u["home_dong"])
        u["home_dong_name"] = d["name"] if d else ""
        u["home_lat"], u["home_lon"] = (d["res_lat"], d["res_lon"]) if d else (None, None)
    if u["facility_id"]:
        f = db.one(con, "SELECT * FROM facilities WHERE id=?", (u["facility_id"],))
        u["facility"] = care.facility_public(f) if f else None
    u["unread"] = db.one(con, "SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read_at IS NULL", (uid,))["n"]
    return u


@route("GET", "/api/me")
def me(req):
    if not req.user:
        return {"user": None}
    return {"user": _me(req.con, req.user["id"])}


@route("PUT", "/api/me", ("parent", "teacher", "city"))
def me_update(req):
    name = (req.b("name") or req.user["name"]).strip()[:30]
    home = req.b("home_dong", req.user["home_dong"])
    if home and home not in refdata.dong_by_code():
        raise ApiError(400, "사는 동을 다시 골라 주세요.")
    req.con.execute("UPDATE users SET name=?, phone=?, home_dong=? WHERE id=?",
                    (name, (req.b("phone") or "")[:20], home, req.user["id"]))
    req.con.commit()
    return {"user": _me(req.con, req.user["id"])}


@route("GET", "/api/dongs")
def dongs(req):
    return {"dongs": analysis.dong_shapes_summary()}


# ── 시설 ────────────────────────────────────────────────
@route("GET", "/api/facilities")
def facilities(req):
    lat, lon = req.q("lat", None, float), req.q("lon", None, float)
    out = []
    for f in db.rows(req.con, "SELECT * FROM facilities WHERE status='operating' ORDER BY id"):
        p = care.facility_public(f)
        if lat is not None and lon is not None:
            p["distance_m"] = round(analysis._dist_km(lat, lon, f["lat"], f["lon"]) * 1000)
        p["today"] = _today_summary(req.con, f)
        today_w = json.loads(f["hours_json"]).get(care.day_type(dt.date.today()))
        p["until_today"] = today_w[1] if today_w else None   # 오늘 몇 시(분)까지 맡길 수 있나
        out.append(p)
    if lat is not None:
        out.sort(key=lambda x: x["distance_m"])
    res = {"facilities": out}
    if req.q("others") and lat is not None and lon is not None:
        res["others"] = _other_care(lat, lon)
    return res


def _other_care(lat: float, lon: float, limit_km: float = 4.0) -> list[dict]:
    """'오늘 어디에 맡길까'용: 근처 기존 늦은 시간 돌봄(예약은 해당 기관). 공개 데이터 기준."""
    b = analysis.base()
    names = refdata.dong_by_code()
    out = []
    for c in b["care"]:
        h, m = map(int, c["close"].split(":"))
        out.append({"name": c["name"], "type": c["type"], "target": "elem", "lat": c["lat"], "lon": c["lon"],
                    "dong_name": names.get(c["dong"], {}).get("name", ""), "until": h * 60 + m, "until_label": f"{c['close']}까지",
                    "source": "돌봄시설 목록(공개)"})
    for c in b["centers"]:
        if "24시간" in c["spec"]:
            until, label = 31 * 60 + 30, "24시간(야간 포함)"
        elif "야간연장" in c["spec"]:
            until, label = 24 * 60, "야간연장 · 24:00까지"
        else:
            continue
        out.append({"name": c["name"], "type": f"어린이집({c['type']})", "target": "preschool", "lat": c["lat"], "lon": c["lon"],
                    "dong_name": c["dong_name"], "until": until, "until_label": label,
                    "note": "다니는 아이 위주로 운영 · 기관 문의", "source": "어린이집 정보공개포털"})
    for o in out:
        o["distance_m"] = round(analysis._dist_km(lat, lon, o["lat"], o["lon"]) * 1000)
    out = [o for o in out if o["distance_m"] <= limit_km * 1000]
    out.sort(key=lambda o: o["distance_m"])
    return out[:40]


def _today_summary(con, f: dict) -> dict:
    if not f["bookable"]:
        return {"open": None}
    av = care.availability(con, f, dt.date.today())
    now = db.now()
    future = [a for a in av if a["open"] and care.parse_dt(a["start"]) + dt.timedelta(hours=1) > now]
    return {"open": bool([a for a in av if a["open"]]), "slots": len(future),
            "free_slots": sum(1 for a in future if a["left"] > 0),
            "min_left": min((a["left"] for a in future), default=0)}


@route("GET", "/api/facilities/{fid}")
def facility_get(req):
    f = db.one(req.con, "SELECT * FROM facilities WHERE id=?", (_int(req.params["fid"]),))
    if not f:
        raise ApiError(404, "시설을 찾을 수 없습니다.")
    return {"facility": care.facility_public(f)}


@route("GET", "/api/facilities/{fid}/availability")
def facility_avail(req):
    f = db.one(req.con, "SELECT * FROM facilities WHERE id=?", (_int(req.params["fid"]),))
    if not f:
        raise ApiError(404, "시설을 찾을 수 없습니다.")
    d = _date(req.q("date"))
    return {"date": d.isoformat(), "day_type": day_type(d), "slots": care.availability(req.con, f, d),
            "facility": care.facility_public(f)}


# ── 아이 ────────────────────────────────────────────────
def _child_out(c: dict) -> dict:
    c = dict(c)
    c["age_label"] = care.age_label(c["birthdate"])
    c["grade"] = care.school_grade(c["birthdate"], dt.date.today())
    c["months"] = care.age_months(c["birthdate"], dt.date.today())
    return c


@route("GET", "/api/children", ("parent",))
def children(req):
    return {"children": [_child_out(c) for c in db.rows(req.con, "SELECT * FROM children WHERE parent_id=? AND active=1 ORDER BY id",
                                                         (req.user["id"],))]}


def _child_payload(req) -> tuple[str, str, str]:
    name = (req.b("name") or "").strip()[:20]
    birth = req.b("birthdate") or ""
    try:
        bd = dt.date.fromisoformat(birth)
    except ValueError:
        raise ApiError(400, "생년월일을 입력해 주세요.")
    if not name:
        raise ApiError(400, "이름을 입력해 주세요.")
    if bd > dt.date.today() or bd < dt.date.today() - dt.timedelta(days=365 * 14):
        raise ApiError(400, "생년월일을 확인해 주세요.")
    return name, birth, (req.b("notes") or "")[:200]


@route("POST", "/api/children", ("parent",))
def child_add(req):
    name, birth, notes = _child_payload(req)
    cid = req.con.execute("INSERT INTO children(parent_id,name,birthdate,notes,created_at) VALUES(?,?,?,?,?)",
                          (req.user["id"], name, birth, notes, db.now_s())).lastrowid
    req.con.commit()
    return {"child": _child_out(db.one(req.con, "SELECT * FROM children WHERE id=?", (cid,)))}


@route("PUT", "/api/children/{cid}", ("parent",))
def child_edit(req):
    cid = _int(req.params["cid"])
    if not db.one(req.con, "SELECT 1 FROM children WHERE id=? AND parent_id=?", (cid, req.user["id"])):
        raise ApiError(404, "아이 정보를 찾을 수 없습니다.")
    name, birth, notes = _child_payload(req)
    req.con.execute("UPDATE children SET name=?, birthdate=?, notes=? WHERE id=?", (name, birth, notes, cid))
    req.con.commit()
    return {"child": _child_out(db.one(req.con, "SELECT * FROM children WHERE id=?", (cid,)))}


@route("DELETE", "/api/children/{cid}", ("parent",))
def child_del(req):
    cid = _int(req.params["cid"])
    if db.one(req.con, f"SELECT 1 FROM reservations WHERE child_id=? AND status IN {care.ACTIVE}", (cid,)):
        raise ApiError(400, "진행 중인 예약이 있어 삭제할 수 없습니다.")
    req.con.execute("UPDATE children SET active=0 WHERE id=? AND parent_id=?", (cid, req.user["id"]))
    req.con.commit()
    return {"ok": True}


# ── 예약(보호자) ──────────────────────────────────────────
RES_SELECT = """SELECT r.*, c.name child_name, c.birthdate child_birth, c.notes child_notes, f.name facility_name, f.kind facility_kind,
                       f.phone facility_phone, u.name parent_name, u.phone parent_phone, u.home_dong parent_dong
                FROM reservations r JOIN children c ON c.id=r.child_id JOIN facilities f ON f.id=r.facility_id
                JOIN users u ON u.id=r.parent_id"""


@route("GET", "/api/reservations", ("parent",))
def my_reservations(req):
    care.sweep(req.con)
    rs = db.rows(req.con, RES_SELECT + " WHERE r.parent_id=? ORDER BY r.start_at DESC LIMIT 200", (req.user["id"],))
    now = care.fmt_dt(db.now())
    out = [care.reservation_view(r) for r in rs]
    upcoming = sorted([r for r in out if r["status"] in care.ACTIVE and r["end_at"] >= now], key=lambda r: r["start_at"])
    past = [r for r in out if r not in upcoming]
    return {"upcoming": upcoming, "past": past}


@route("GET", "/api/reservations/{rid}", ("parent",))
def my_reservation(req):
    r = db.one(req.con, RES_SELECT + " WHERE r.id=? AND r.parent_id=?", (_int(req.params["rid"]), req.user["id"]))
    if not r:
        raise ApiError(404, "예약을 찾을 수 없습니다.")
    return {"reservation": care.reservation_view(r)}


@route("POST", "/api/reservations", ("parent",))
def reserve(req):
    try:
        out = care.create_reservation(req.con, req.user, _int(req.b("facility_id"), "facility_id"), _int(req.b("child_id"), "child_id"),
                                      req.b("start") or "", req.b("end") or "", req.b("note") or "")
    except care.BookingError as e:
        raise ApiError(409 if e.code == "full" else 400, str(e), e.code)
    req.con.commit()
    return out


@route("POST", "/api/reservations/{rid}/cancel", ("parent",))
def reserve_cancel(req):
    try:
        care.cancel_reservation(req.con, req.user, _int(req.params["rid"]))
    except care.BookingError as e:
        raise ApiError(400, str(e), e.code)
    req.con.commit()
    return {"ok": True}


# ── 수요 등록 ────────────────────────────────────────────
SLOT_KO = {"weekday_18_20": "평일 18~20시", "weekday_20_22": "평일 20~22시", "night_22_07": "밤 22시~아침 7시",
           "sat": "토요일", "holiday": "일요일·공휴일"}
AGE_KO = {"infant": "영아(0~2세)", "preschool": "유아(3~7세)", "elem": "초등학생"}


@route("GET", "/api/demand", ("parent",))
def demand_mine(req):
    rs = db.rows(req.con, "SELECT * FROM demand_requests WHERE parent_id=? ORDER BY id DESC", (req.user["id"],))
    names = refdata.dong_by_code()
    for r in rs:
        r["dong_name"] = names[r["dong"]]["name"]
        r["slots_label"] = [SLOT_KO.get(s, s) for s in r["slots"].split(",")]
        r["age_label"] = AGE_KO[r["age_group"]]
    return {"requests": rs}


@route("POST", "/api/demand", ("parent",))
def demand_add(req):
    dong = req.b("dong")
    age = req.b("age_group")
    slots = [s for s in (req.b("slots") or []) if s in SLOT_KO]
    if dong not in refdata.dong_by_code():
        raise ApiError(400, "동을 골라 주세요.")
    if age not in AGE_KO:
        raise ApiError(400, "아이 나이를 골라 주세요.")
    if not slots:
        raise ApiError(400, "필요한 시간대를 하나 이상 골라 주세요.")
    if db.one(req.con, "SELECT COUNT(*) n FROM demand_requests WHERE parent_id=?", (req.user["id"],))["n"] >= 5:
        raise ApiError(400, "한 계정에서 최대 5건까지 등록할 수 있어요.")
    req.con.execute("INSERT INTO demand_requests(parent_id,dong,age_group,slots,note,created_at) VALUES(?,?,?,?,?,?)",
                    (req.user["id"], dong, age, ",".join(slots), (req.b("note") or "")[:200], db.now_s()))
    req.con.commit()
    return {"ok": True}


@route("DELETE", "/api/demand/{did}", ("parent",))
def demand_del(req):
    req.con.execute("DELETE FROM demand_requests WHERE id=? AND parent_id=?", (_int(req.params["did"]), req.user["id"]))
    req.con.commit()
    return {"ok": True}


def _registrations(con) -> dict:
    return {r["dong"]: r["n"] for r in db.rows(con, "SELECT dong, COUNT(*) n FROM demand_requests GROUP BY dong")}


@route("GET", "/api/demand/summary")
def demand_summary(req):
    names = refdata.dong_by_code()
    regs = _registrations(req.con)
    return {"by_dong": sorted([{"code": c, "name": names[c]["name"], "count": n} for c, n in regs.items()], key=lambda x: -x["count"]),
            "total": sum(regs.values())}


# ── 알림·메시지 ─────────────────────────────────────────
@route("GET", "/api/notifications", ("parent", "teacher", "city"))
def notifications(req):
    rs = db.rows(req.con, "SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100", (req.user["id"],))
    return {"notifications": rs, "unread": sum(1 for r in rs if not r["read_at"])}


@route("POST", "/api/notifications/read", ("parent", "teacher", "city"))
def notifications_read(req):
    req.con.execute("UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL", (db.now_s(), req.user["id"]))
    req.con.commit()
    return {"ok": True}


@route("GET", "/api/threads", ("parent", "teacher"))
def threads(req):
    if req.user["role"] == "parent":
        where, arg, unread_col = "t.parent_id=?", req.user["id"], "read_by_parent"
    else:
        where, arg, unread_col = "t.facility_id=?", req.user["facility_id"], "read_by_facility"
    rs = db.rows(req.con, f"""SELECT t.id, t.facility_id, t.parent_id, f.name facility_name, u.name parent_name,
                                 (SELECT body FROM messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) last_body,
                                 (SELECT created_at FROM messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) last_at,
                                 (SELECT COUNT(*) FROM messages m WHERE m.thread_id=t.id AND m.{unread_col}=0) unread
                          FROM threads t JOIN facilities f ON f.id=t.facility_id JOIN users u ON u.id=t.parent_id
                          WHERE {where} ORDER BY last_at DESC""", (arg,))
    return {"threads": rs}


@route("POST", "/api/threads", ("parent",))
def thread_open(req):
    fid = _int(req.b("facility_id"), "facility_id")
    if not db.one(req.con, "SELECT 1 FROM facilities WHERE id=? AND bookable=1", (fid,)):
        raise ApiError(404, "시설을 찾을 수 없습니다.")
    tid = care.thread_for(req.con, fid, req.user["id"])
    req.con.commit()
    return {"thread_id": tid}


@route("GET", "/api/threads/{tid}", ("parent", "teacher"))
def thread_get(req):
    tid = _int(req.params["tid"])
    th = db.one(req.con, """SELECT t.*, f.name facility_name, u.name parent_name FROM threads t JOIN facilities f ON f.id=t.facility_id
                            JOIN users u ON u.id=t.parent_id WHERE t.id=?""", (tid,))
    if not th or not care.can_access_thread(req.user, th):
        raise ApiError(404, "대화를 찾을 수 없습니다.")
    col = "read_by_parent" if req.user["role"] == "parent" else "read_by_facility"
    req.con.execute(f"UPDATE messages SET {col}=1 WHERE thread_id=?", (tid,))
    req.con.commit()
    msgs = db.rows(req.con, """SELECT m.id, m.sender_id, u.name sender_name, u.role sender_role, m.body, m.created_at
                               FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.thread_id=? ORDER BY m.id""", (tid,))
    return {"thread": th, "messages": msgs}


@route("POST", "/api/threads/{tid}/messages", ("parent", "teacher"))
def thread_send(req):
    try:
        msg = care.send_message(req.con, req.user, _int(req.params["tid"]), req.b("body") or "")
    except care.BookingError as e:
        raise ApiError(400, str(e), e.code)
    req.con.commit()
    return {"message": msg}


# ── 돌봄교사 ────────────────────────────────────────────
@route("GET", "/api/teacher/roster", ("teacher",))
def roster(req):
    care.sweep(req.con)
    f = db.one(req.con, "SELECT * FROM facilities WHERE id=?", (req.user["facility_id"],))
    if not f:
        raise ApiError(404, "담당 시설이 없습니다.")
    d = _date(req.q("date"))
    if f["kind"] == "hub":
        s, e = dt.datetime.combine(d, dt.time(7)), dt.datetime.combine(d + dt.timedelta(days=1), dt.time(7))
    else:
        s, e = dt.datetime.combine(d, dt.time()), dt.datetime.combine(d + dt.timedelta(days=1), dt.time())
    rs = db.rows(req.con, RES_SELECT + " WHERE r.facility_id=? AND r.start_at < ? AND r.end_at > ? AND r.status != 'cancelled' ORDER BY r.start_at",
                 (f["id"], care.fmt_dt(e), care.fmt_dt(s)))
    names = refdata.dong_by_code()
    out = []
    for r in rs:
        v = care.reservation_view(r)
        v.pop("pickup_code", None)
        v["parent_dong_name"] = names.get(r["parent_dong"] or "", {}).get("name", "")
        out.append(v)
    counts = Counter(r["status"] for r in out)
    return {"facility": care.facility_public(f), "date": d.isoformat(), "reservations": out, "slots": care.availability(req.con, f, d),
            "counts": {k: counts.get(k, 0) for k in care.STATUS_KO}, "now": db.now_s()}


@route("POST", "/api/teacher/reservations/{rid}/checkin", ("teacher",))
def t_checkin(req):
    try:
        out = care.check_in(req.con, req.user, _int(req.params["rid"]))
    except care.BookingError as e:
        raise ApiError(400, str(e), e.code)
    req.con.commit()
    return out


@route("POST", "/api/teacher/reservations/{rid}/checkout", ("teacher",))
def t_checkout(req):
    try:
        out = care.check_out(req.con, req.user, _int(req.params["rid"]), req.b("code") or "", req.b("override") or "")
    except care.BookingError as e:
        raise ApiError(400, str(e), e.code)
    req.con.commit()
    return out


# ── 시(분석·운영) ───────────────────────────────────────
def _settings(con) -> dict:
    return db.get_setting(con, "analysis", {"weights": {"night": 1, "late": 1, "hol": 1, "sandan": 1}, "radius_km": 1.0, "threshold_km": 2.5})


def _weights(req) -> dict:
    s = _settings(req.con)["weights"]
    return {k: req.q(f"w_{k}", s.get(k, 1), float) for k, _, _ in analysis.COMPONENTS}


def _plan(con) -> list[dict]:
    return db.rows(con, "SELECT * FROM hub_plan ORDER BY slot")


@route("GET", "/api/city/settings", ("city",))
def city_settings(req):
    return {"settings": _settings(req.con), "components": [{"key": k, "label": l, "source": s} for k, l, s in analysis.COMPONENTS]}


@route("PUT", "/api/city/settings", ("city",))
def city_settings_put(req):
    cur = _settings(req.con)
    w = req.b("weights") or cur["weights"]
    new = {"weights": {k: max(0.0, min(5.0, float(w.get(k, 1)))) for k, _, _ in analysis.COMPONENTS},
           "radius_km": max(0.5, min(3.0, float(req.b("radius_km", cur["radius_km"])))),
           "threshold_km": max(1.0, min(6.0, float(req.b("threshold_km", cur["threshold_km"]))))}
    db.set_setting(req.con, "analysis", new)
    db.audit(req.con, req.user["id"], "settings", new)
    req.con.commit()
    return {"settings": new}


@route("GET", "/api/city/overview", ("city",))
def city_overview(req):
    con = req.con
    care.sweep(con)
    now = db.now()
    today_s = care.fmt_dt(dt.datetime.combine(dt.date.today(), dt.time()))
    tomorrow_s = care.fmt_dt(dt.datetime.combine(dt.date.today() + dt.timedelta(days=1), dt.time()))
    facs = db.rows(con, "SELECT * FROM facilities WHERE status='operating' ORDER BY id")
    present = db.one(con, "SELECT COUNT(*) n FROM reservations WHERE status='checked_in'")["n"]
    today_n = db.one(con, "SELECT COUNT(*) n FROM reservations WHERE start_at>=? AND start_at<? AND status!='cancelled'", (today_s, tomorrow_s))["n"]
    week_ago = care.fmt_dt(now - dt.timedelta(days=7))
    fails = db.one(con, "SELECT COUNT(*) n FROM booking_failures WHERE created_at>=?", (week_ago,))["n"]
    regs = db.one(con, "SELECT COUNT(*) n FROM demand_requests")["n"]
    regs30 = db.one(con, "SELECT COUNT(*) n FROM demand_requests WHERE created_at>=?", (care.fmt_dt(now - dt.timedelta(days=30)),))["n"]
    spaces = Counter(r["status"] for r in db.rows(con, "SELECT status FROM spaces"))
    table = analysis.dong_table(_weights(req), _registrations(con))
    return {"facilities": [care.facility_public(f) for f in facs], "present_now": present, "today_reservations": today_n,
            "failures_7d": fails, "registrations": regs, "registrations_30d": regs30, "spaces": dict(spaces),
            "plan": _plan(con), "top_gap": table[:5], "virtual": analysis.base()["virtual"], "built_at": analysis.base()["built_at"]}


@route("GET", "/api/city/dongs", ("city",))
def city_dongs(req):
    return {"dongs": analysis.dong_table(_weights(req), _registrations(req.con)), "weights": _weights(req)}


@route("GET", "/api/city/candidates", ("city",))
def city_candidates(req):
    radius = req.q("radius", _settings(req.con)["radius_km"], float)
    res = analysis.hub_candidates(_weights(req), max(0.5, min(3.0, radius)))
    plan = {p["stcode"]: p["slot"] for p in _plan(req.con)}
    for c in res["candidates"]:
        c["plan_slot"] = plan.get(c["id"])
    return res


@route("GET", "/api/city/forecast", ("city",))
def city_forecast(req):
    radius = req.q("radius", _settings(req.con)["radius_km"], float)
    uptake = req.q("uptake", 3.0, float)
    per_teacher = req.q("per_teacher", None, float)
    staffing = req.q("staffing")
    staffing = [max(0, min(6, int(x))) for x in staffing.split(",")] if staffing else None
    fid = req.q("facility_id", None, int)
    stcode = req.q("stcode")
    if fid:
        f = db.one(req.con, "SELECT * FROM facilities WHERE id=?", (fid,))
        if not f:
            raise ApiError(404, "시설을 찾을 수 없습니다.")
        lat, lon, name = f["lat"], f["lon"], f["name"]
        staffing = staffing or (json.loads(f["staffing_json"]) if f["staffing_json"] else None)
        per_teacher = per_teacher or f["per_teacher"]
    elif stcode:
        c = next((c for c in analysis.base()["centers"] if c["id"] == stcode), None)
        if not c:
            raise ApiError(404, "후보를 찾을 수 없습니다.")
        lat, lon, name = c["lat"], c["lon"], c["name"]
    else:
        raise ApiError(400, "facility_id 또는 stcode가 필요합니다.")
    fc = analysis.forecast(lat, lon, radius, uptake, staffing, per_teacher or 5.0)
    fc["name"] = name
    return fc


@route("GET", "/api/city/plan", ("city",))
def city_plan(req):
    return {"plan": _plan(req.con)}


@route("PUT", "/api/city/plan", ("city",))
def city_plan_put(req):
    slot = _int(req.b("slot"), "slot")
    if slot not in (1, 2):
        raise ApiError(400, "slot은 1(2027) 또는 2(2028)입니다.")
    c = next((c for c in analysis.base()["centers"] if c["id"] == req.b("stcode") and c["type"] == "국공립"), None)
    if not c:
        raise ApiError(404, "시립어린이집 후보를 찾을 수 없습니다.")
    other = db.one(req.con, "SELECT stcode FROM hub_plan WHERE slot!=?", (slot,))
    if other and other["stcode"] == c["id"]:
        raise ApiError(400, "이미 다른 해에 지정한 후보입니다.")
    req.con.execute("""INSERT INTO hub_plan(slot,year,stcode,name,dong,lat,lon,memo,updated_at,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(slot) DO UPDATE SET stcode=excluded.stcode,name=excluded.name,dong=excluded.dong,lat=excluded.lat,
                       lon=excluded.lon,memo=excluded.memo,updated_at=excluded.updated_at,updated_by=excluded.updated_by""",
                    (slot, 2026 + slot, c["id"], c["name"], c["dong"], c["lat"], c["lon"], (req.b("memo") or "")[:300], db.now_s(), req.user["id"]))
    db.audit(req.con, req.user["id"], "hub_plan", {"slot": slot, "stcode": c["id"], "name": c["name"], "memo": req.b("memo") or ""})
    req.con.commit()
    return {"plan": _plan(req.con)}


@route("GET", "/api/city/coverage", ("city",))
def city_coverage(req):
    th = req.q("threshold", _settings(req.con)["threshold_km"], float)
    hubs = [{"lat": p["lat"], "lon": p["lon"], "name": p["name"], "slot": p["slot"]} for p in _plan(req.con)]
    cov = analysis.coverage(hubs, max(1.0, min(6.0, th)), _weights(req), _registrations(req.con))
    rooms = [care.facility_public(f) for f in db.rows(req.con, "SELECT * FROM facilities WHERE kind='room' AND status='operating'")]
    cov["rooms"] = rooms
    cov["profiles"] = [analysis.return_profile(d["code"]) for d in cov["dongs"][:6]]
    return cov


@route("GET", "/api/city/return-profile", ("city",))
def city_return_profile(req):
    code = req.q("dong")
    if code not in refdata.dong_by_code():
        raise ApiError(400, "동 코드가 올바르지 않습니다.")
    return analysis.return_profile(code)


SPACE_STATUS = {"candidate": "후보", "site_visit": "현장 확인 예정", "suitable": "적합", "unsuitable": "부적합",
                "agreement": "협약 진행", "operating": "운영 중"}


def _spaces(req) -> list[dict]:
    rs = db.rows(req.con, "SELECT * FROM spaces ORDER BY id")
    for r in rs:
        r["checks"] = json.loads(r.pop("checks_json") or "{}")
        r["elevator"] = None if r["elevator"] is None else bool(r["elevator"])
        r["status_label"] = SPACE_STATUS.get(r["status"], r["status"])
    return rs


@route("GET", "/api/city/spaces", ("city",))
def city_spaces(req):
    th = req.q("threshold", _settings(req.con)["threshold_km"], float)
    target = req.q("target", "elem")
    hubs = [{"lat": p["lat"], "lon": p["lon"]} for p in _plan(req.con)]
    regs = _registrations(req.con)
    cov = analysis.coverage(hubs, th, _weights(req), regs)
    return {"spaces": analysis.score_spaces(_spaces(req), cov, target, regs), "status_labels": SPACE_STATUS, "target": target}


@route("POST", "/api/city/spaces", ("city",))
def city_space_add(req):
    lat, lon = req.b("lat"), req.b("lon")
    try:
        lat, lon = float(lat), float(lon)
    except (TypeError, ValueError):
        raise ApiError(400, "지도에서 위치를 찍어 주세요.")
    d = refdata.locate_dong(lat, lon)
    if not d:
        raise ApiError(400, "안산시 안의 위치를 골라 주세요.")
    kind = req.b("kind")
    if kind not in analysis.SPACE_KIND:
        raise ApiError(400, "공간 종류를 골라 주세요.")
    name = (req.b("name") or "").strip()[:80]
    if not name:
        raise ApiError(400, "공간 이름을 입력해 주세요.")
    sid = req.con.execute("""INSERT INTO spaces(kind,name,dong,lat,lon,floor,area,elevator,source,source_note,status,checks_json,memo,updated_at,updated_by)
                             VALUES(?,?,?,?,?,?,?,?,?,?,'candidate','{}',?,?,?)""",
                          (kind, name, d["code"], lat, lon, req.b("floor"), req.b("area"),
                           None if req.b("elevator") is None else int(bool(req.b("elevator"))), "manual", "담당자 직접 등록",
                           (req.b("memo") or "")[:500], db.now_s(), req.user["id"])).lastrowid
    db.audit(req.con, req.user["id"], "space_add", {"id": sid, "name": name})
    req.con.commit()
    return {"id": sid}


@route("PUT", "/api/city/spaces/{sid}", ("city",))
def city_space_put(req):
    sid = _int(req.params["sid"])
    s = db.one(req.con, "SELECT * FROM spaces WHERE id=?", (sid,))
    if not s:
        raise ApiError(404, "공간 후보를 찾을 수 없습니다.")
    status = req.b("status", s["status"])
    if status not in SPACE_STATUS:
        raise ApiError(400, "상태 값이 올바르지 않습니다.")
    checks = req.b("checks")
    checks = json.loads(s["checks_json"] or "{}") if checks is None else {k: checks.get(k) for k in ("fire", "exit", "insurance", "owner")}
    floor = req.b("floor", s["floor"])
    area = req.b("area", s["area"])
    elev = req.b("elevator", None if s["elevator"] is None else bool(s["elevator"]))
    if status == "operating" and not all(checks.get(k) is True for k in ("fire", "exit", "insurance")):
        raise ApiError(400, "운영으로 바꾸려면 소방·비상구·보험 확인이 모두 '적합'이어야 합니다.")
    fid = s["facility_id"]
    if status == "operating" and not fid:
        d = refdata.dong_by_code()[s["dong"]]
        from .seed import ROOM_HOURS
        fid = req.con.execute("""INSERT INTO facilities(kind,name,dong,lat,lon,address,phone,target,hours_json,per_teacher,room_capacity,
                                 fee_per_hour,bookable,status,status_label,source_ref,created_at)
                                 VALUES('room',?,?,?,?,?,?,'elem',?,10,15,0,1,'operating','시범 돌봄방 · 이용료 검토 중',?,?)""",
                              (f"{d['name']} 늦은 시간 돌봄방({sid})", s["dong"], s["lat"], s["lon"], s["name"], "", json.dumps(ROOM_HOURS),
                               f"space:{sid}", db.now_s())).lastrowid
    if status != "operating" and fid:
        req.con.execute("UPDATE facilities SET status='paused' WHERE id=?", (fid,))
    elif status == "operating" and fid:
        req.con.execute("UPDATE facilities SET status='operating' WHERE id=?", (fid,))
    req.con.execute("""UPDATE spaces SET status=?, checks_json=?, memo=?, floor=?, area=?, elevator=?, facility_id=?, updated_at=?, updated_by=?
                       WHERE id=?""",
                    (status, json.dumps(checks), (req.b("memo", s["memo"]) or "")[:500], floor, area,
                     None if elev is None else int(bool(elev)), fid, db.now_s(), req.user["id"], sid))
    db.audit(req.con, req.user["id"], "space_update", {"id": sid, "name": s["name"], "status": status, "checks": checks})
    req.con.commit()
    return {"ok": True, "facility_id": fid}


@route("PUT", "/api/city/facilities/{fid}/staffing", ("city",))
def city_staffing(req):
    fid = _int(req.params["fid"])
    f = db.one(req.con, "SELECT * FROM facilities WHERE id=? AND kind='hub'", (fid,))
    if not f:
        raise ApiError(404, "거점 센터를 찾을 수 없습니다.")
    st = req.b("staffing")
    if not isinstance(st, list) or len(st) != 24:
        raise ApiError(400, "24시간 교사 배치표가 필요합니다.")
    st = [max(0, min(6, int(x))) for x in st]
    pt = max(1.0, min(15.0, float(req.b("per_teacher", f["per_teacher"]))))
    req.con.execute("UPDATE facilities SET staffing_json=?, per_teacher=? WHERE id=?", (json.dumps(st), pt, fid))
    db.audit(req.con, req.user["id"], "staffing", {"facility": f["name"], "staffing": st, "per_teacher": pt})
    req.con.commit()
    care.ping_staff(req.con, fid)
    return {"ok": True}


@route("GET", "/api/city/usage", ("city",))
def city_usage(req):
    days = max(7, min(90, req.q("days", 28, int)))
    con = req.con
    care.sweep(con)
    end_d = dt.date.today()
    start_d = end_d - dt.timedelta(days=days)
    s_str, e_str = care.fmt_dt(dt.datetime.combine(start_d, dt.time())), care.fmt_dt(dt.datetime.combine(end_d, dt.time()))
    names = refdata.dong_by_code()
    out = []
    for f in db.rows(con, "SELECT * FROM facilities WHERE bookable=1 AND status='operating' ORDER BY id"):
        rs = db.rows(con, """SELECT r.*, c.birthdate, u.home_dong FROM reservations r JOIN children c ON c.id=r.child_id
                             JOIN users u ON u.id=r.parent_id WHERE r.facility_id=? AND r.start_at>=? AND r.start_at<?""",
                     (f["id"], s_str, e_str))
        st = Counter(r["status"] for r in rs)
        used = [r for r in rs if r["status"] == "checked_out"]
        child_hours = sum((care.parse_dt(r["checkout_at"]) - care.parse_dt(r["checkin_at"])).total_seconds() / 3600
                          for r in used if r["checkin_at"] and r["checkout_at"])
        prof = {"weekday": [0.0] * 24, "holiday": [0.0] * 24}
        ndays = Counter()
        d = start_d
        while d < end_d:
            ndays["weekday" if day_type(d) == "weekday" else "holiday"] += 1
            d += dt.timedelta(days=1)
        cap = {"weekday": [0] * 24, "holiday": [0] * 24}
        for t in ("weekday", "holiday"):
            for h in range(24):
                if f["kind"] == "hub":
                    cap[t][h] = care.capacity_at(f, dt.datetime(2026, 1, 1, h))
                else:  # 돌봄방은 평일 운영 시간(18~22시)에만 정원
                    cap[t][h] = (f["room_capacity"] or 0) if (t == "weekday" and 18 <= h < 22) or (t == "holiday" and 10 <= h < 20) else 0
        for r in rs:
            if r["status"] not in ("checked_out", "checked_in"):
                continue
            a, b = care.parse_dt(r["start_at"]), care.parse_dt(r["end_at"])
            for t0 in care.hour_slots(a, b):
                key = "weekday" if day_type(t0.date()) == "weekday" else "holiday"
                prof[key][t0.hour] += 1
        for t in prof:
            prof[t] = [round(v / max(1, ndays[t]), 2) for v in prof[t]]
        fails = db.rows(con, "SELECT start_at FROM booking_failures WHERE facility_id=? AND created_at>=?", (f["id"], s_str))
        fail_h = [0] * 24
        for x in fails:
            fail_h[care.parse_dt(x["start_at"]).hour] += 1
        homes = Counter(names.get(r["home_dong"] or "", {}).get("name", "미등록") for r in rs if r["status"] != "cancelled")
        ages = Counter()
        for r in rs:
            g = care.school_grade(r["birthdate"], care.parse_dt(r["start_at"]).date())
            m = care.age_months(r["birthdate"], care.parse_dt(r["start_at"]).date())
            ages["초등" if g >= 1 else ("영아(0~2세)" if m < 36 else "유아(3세~)")] += 1
        daily = Counter(r["start_at"][:10] for r in rs if r["status"] != "cancelled")
        # 시간대 정원 대비 이용률(운영 시간 평균)
        util_num = sum(prof["weekday"][h] for h in range(24) if cap["weekday"][h])
        util_den = sum(cap["weekday"][h] for h in range(24) if cap["weekday"][h])
        out.append({"facility": care.facility_public(f), "total": len(rs), "status": dict(st), "children": len({r["child_id"] for r in rs}),
                    "child_hours": round(child_hours), "revenue": sum(r["fee"] for r in used),
                    "no_show_rate": round(st.get("no_show", 0) / max(1, len(rs) - st.get("cancelled", 0)) * 100, 1),
                    "profile": prof, "capacity": cap, "failures": len(fails), "failures_by_hour": fail_h,
                    "homes": homes.most_common(8), "ages": dict(ages),
                    "daily": [{"date": (start_d + dt.timedelta(days=i)).isoformat(), "n": daily.get((start_d + dt.timedelta(days=i)).isoformat(), 0)}
                              for i in range(days)],
                    "utilization": round(util_num / util_den * 100, 1) if util_den else None})
    return {"days": days, "from": start_d.isoformat(), "to": end_d.isoformat(), "facilities": out}


@route("GET", "/api/city/demand", ("city",))
def city_demand(req):
    names = refdata.dong_by_code()
    rs = db.rows(req.con, "SELECT * FROM demand_requests")
    by = defaultdict(lambda: {"total": 0, "age": Counter(), "slots": Counter()})
    for r in rs:
        x = by[r["dong"]]
        x["total"] += 1
        x["age"][r["age_group"]] += 1
        for s in r["slots"].split(","):
            x["slots"][s] += 1
    rows = [{"code": c, "name": names[c]["name"], "total": v["total"], "age": dict(v["age"]), "slots": dict(v["slots"])} for c, v in by.items()]
    rows.sort(key=lambda r: -r["total"])
    slot_tot = Counter()
    age_tot = Counter()
    for r in rs:
        age_tot[r["age_group"]] += 1
        for s in r["slots"].split(","):
            slot_tot[s] += 1
    return {"by_dong": rows, "total": len(rs), "slots": dict(slot_tot), "ages": dict(age_tot), "slot_labels": SLOT_KO, "age_labels": AGE_KO}


@route("GET", "/api/city/datasets", ("city",))
def city_datasets(req):
    b = analysis.base()
    return {"datasets": b["registry"], "built_at": b["built_at"], "virtual": b["virtual"], "days": b["days"]}


@route("POST", "/api/city/recompute", ("city",))
def city_recompute(req):
    b = analysis.rebuild()
    db.audit(req.con, req.user["id"], "recompute", {"built_at": b["built_at"]})
    req.con.commit()
    return {"built_at": b["built_at"], "datasets": b["registry"]}


@route("GET", "/api/city/audit", ("city",))
def city_audit(req):
    rs = db.rows(req.con, """SELECT a.*, u.name user_name FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 100""")
    for r in rs:
        r["detail"] = json.loads(r["detail"] or "{}")
    return {"audit": rs}


@route("GET", "/api/city/geo-layers", ("city",))
def city_geo_layers(req):
    b = analysis.base()
    return {"care": b["care"], "centers": [{k: c[k] for k in ("name", "type", "lat", "lon", "spec", "dong_name", "capacity")} for c in b["centers"]],
            "sites": b["sites"], "blocks": b["blocks"][:60]}


def export_csv(req, name: str) -> tuple[str, bytes]:
    """CSV 내려받기 (엑셀에서 바로 열리도록 UTF-8 BOM)."""
    buf = io.StringIO()
    w = csv.writer(buf)
    if name == "dongs":
        rows = analysis.dong_table(_weights(req), _registrations(req.con))
        w.writerow(["행정동코드", "행정동", "구", "야간출근(일평균)", "심야귀가(일평균)", "휴일출근(일평균)", "산단통근거주", "영유아", "초등",
                    "수요지수", "공급지수", "공백", "주민수요등록"])
        for r in rows:
            w.writerow([r["code"], r["name"], r["gu"], r["night"], r["late"], r["hol"], r["sandan"], r["kids"], r["elem"], r["demand"],
                        r["supply"], r["gap"], r["registrations"]])
    elif name == "candidates":
        res = analysis.hub_candidates(_weights(req), req.q("radius", _settings(req.con)["radius_km"], float))
        w.writerow(["순위", "시설", "행정동", "점수", "야간출근점수", "심야귀가점수", "휴일출근점수", "산단통근점수", "z합", "시기준점수", "시기준순위",
                    "반경내인구", "반경내영유아", "산단거리km"])
        for c in res["candidates"]:
            p = c["points"]
            w.writerow([c["rank"], c["name"], c["dong_name"], c["score"], p["night"], p["late"], p["hol"], p["sandan"], c["z_sum"],
                        c["city_score"], c["city_rank"], c["pop"], c["kids"], c["site_km"]])
    elif name == "spaces":
        res = city_spaces(req)["spaces"]
        w.writerow(["순위", "공간", "종류", "행정동", "상태", "총점", "수요", "접근성", "적합도", "층", "면적㎡", "도보10분 아동수", "근거"])
        for i, s in enumerate(res):
            w.writerow([i + 1, s["name"], s["kind_label"], s["dong_name"], s["status_label"], s["total"], s["scores"]["demand"],
                        s["scores"]["access"], s["scores"]["fit"], s["floor"], s["area"], s["kids_800m"], s["source_note"]])
    else:
        raise ApiError(404, "없는 내보내기입니다.")
    return f"{name}_{dt.date.today():%Y%m%d}.csv", ("﻿" + buf.getvalue()).encode("utf-8")
