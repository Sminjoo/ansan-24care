"""데모 데이터 채우기(운영 화면 시연용 가상 데이터).

- 거점 2곳: 시가 지정했다고 가정한 시립어린이집 2곳(시연용 고정값, 실제 위치는 시가 공약 47 기준으로 지정)
- 돌봄방 2곳: 거점에서 먼 동의 공간 후보 상위(공공 유휴공간·문 닫은 어린이집)를 '시범 운영'으로 가정
- 최근 4주 이용 기록, 오늘 예약, 수요 등록을 만든다
"""
from __future__ import annotations

import datetime as dt
import json
import math
import random

from . import analysis, auth, care, db, refdata

DEMO_PW = "demo1234"
HUB_HOURS = {"weekday": [450, 1890], "sat": [450, 1890], "holiday": [450, 1890]}     # 07:30~다음 날 07:30
ROOM_HOURS = {"weekday": [1080, 1320], "sat": [600, 1200], "holiday": None}          # 평일 18~22, 토 10~20
TIMECARE_HOURS = {"weekday": [540, 1080], "sat": None, "holiday": None}

GIVEN = ["하윤", "서준", "지안", "도윤", "서아", "이준", "하은", "시우", "지유", "은우", "수아", "예준", "유나", "주원", "채원",
         "지호", "다인", "건우", "소율", "우진", "아린", "선우", "나은", "연우", "로아", "도현", "윤슬", "민재", "하린", "태오"]
FAMILY = ["김", "이", "박", "최", "정", "강", "조", "윤", "장", "임", "한", "오", "서", "신", "권", "황", "안", "송", "류", "홍"]
PARENT_GIVEN = ["지현", "민수", "수진", "현우", "은영", "성민", "미영", "준호", "혜진", "동현", "선영", "재훈", "유진", "상우", "보람"]


def _user(con, username, role, name, home_dong=None, facility_id=None, phone=None, demo=0) -> int:
    h, s = auth.hash_pw(DEMO_PW)
    return con.execute("""INSERT INTO users(username,pw_hash,salt,role,name,phone,home_dong,facility_id,demo,created_at)
                          VALUES(?,?,?,?,?,?,?,?,?,?)""",
                       (username, h, s, role, name, phone, home_dong, facility_id, demo, db.now_s())).lastrowid


def _facility(con, **kw) -> int:
    cols = ",".join(kw)
    q = ",".join("?" * len(kw))
    return con.execute(f"INSERT INTO facilities({cols},created_at) VALUES({q},?)", (*kw.values(), db.now_s())).lastrowid


def _birth_for(rng: random.Random, kind: str, today: dt.date) -> str:
    if kind == "infant":
        d = today - dt.timedelta(days=rng.randint(200, 1050))
    elif kind == "preschool":
        d = today - dt.timedelta(days=rng.randint(1100, 2250))
    else:
        d = dt.date(today.year - rng.randint(7, 12), rng.randint(3, 12), rng.randint(1, 28))
    return d.isoformat()


def seed(con) -> None:
    rng = random.Random(47)
    today = dt.date.today()
    dongs = refdata.dong_by_code()

    hc = analysis.hub_candidates()["candidates"]
    h1, h2 = hc[0], hc[1]
    timecare_src = next((c for c in analysis.base()["centers"] if "시간제보육" in c["spec"]), None)

    # 시설
    staffing = json.dumps(analysis.DEFAULT_STAFFING)
    hub_ids = []
    for i, h in enumerate((h1, h2)):
        hub_ids.append(_facility(
            con, kind="hub", name=f"{h['name']} 24시간 거점", dong=h["dong"], lat=h["lat"], lon=h["lon"],
            address=f"경기도 안산시 {dongs[h['dong']]['gu']} {h['dong_name']} (가상 주소)", phone=f"031-000-{1001 + i}",
            age_min_m=6, age_max_m=83, target="infant_preschool", hours_json=json.dumps(HUB_HOURS), staffing_json=staffing,
            per_teacher=5, fee_per_hour=3000, bookable=1, status="operating",
            status_label="시범 운영(가정)" if i == 0 else "2028년 추가 지정 예정 · 시범 운영(가정)", source_ref=h["id"]))
    if timecare_src:
        _facility(con, kind="timecare", name=f"{timecare_src['name']} 시간제 보육실", dong=timecare_src["dong"],
                  lat=timecare_src["lat"], lon=timecare_src["lon"], address=f"경기도 안산시 단원구 {timecare_src['dong_name']} (가상 주소)",
                  phone="031-000-1000", age_min_m=6, age_max_m=36, target="infant", hours_json=json.dumps(TIMECARE_HOURS),
                  per_teacher=3, room_capacity=6, fee_per_hour=0, bookable=0, status="operating",
                  status_label="기존 운영 · 예약은 기존 경로", source_ref=timecare_src["id"])

    # 거점 지정안
    for slot, h, year in ((1, h1, 2027), (2, h2, 2028)):
        con.execute("INSERT INTO hub_plan(slot,year,stcode,name,dong,lat,lon,memo,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                    (slot, year, h["id"], h["name"], h["dong"], h["lat"], h["lon"], "공약 47 시 지정 거점(시연용 가정)", db.now_s()))
    db.set_setting(con, "analysis", {"weights": {"night": 1, "late": 1, "hol": 1, "sandan": 1}, "radius_km": 1.0, "threshold_km": 2.5})

    # 공간 후보
    hubs = [{"lat": h1["lat"], "lon": h1["lon"]}, {"lat": h2["lat"], "lon": h2["lon"]}]
    cov = analysis.coverage(hubs, 2.5)
    spaces = analysis.initial_spaces()
    for s in spaces:
        s["checks"] = {}
    scored = analysis.score_spaces(spaces, cov)
    room_picks, used_dongs = [], set()
    for s in scored:
        far_enough = all(analysis._dist_km(s["lat"], s["lon"], o["lat"], o["lon"]) > 2.5 for o in room_picks)
        if s["kind"] in ("public_idle", "closed_daycare") and s["dong"] not in used_dongs and s["remaining_gap"] > 0 and far_enough:
            room_picks.append(s)
            used_dongs.add(s["dong"])
        if len(room_picks) == 2:
            break
    status_plan = {}
    for i, s in enumerate(scored):
        if s in room_picks:
            status_plan[s["name"]] = ("operating", {"fire": True, "exit": True, "insurance": True, "owner": True})
        elif i in (0, 1, 2):
            status_plan[s["name"]] = ("site_visit", {})
        elif i in (3, 4):
            status_plan[s["name"]] = ("suitable", {"fire": True, "exit": True, "insurance": None, "owner": None})
        elif i == 6:
            status_plan[s["name"]] = ("unsuitable", {"fire": False, "exit": True, "insurance": None, "owner": None})
    room_ids = []
    for s in spaces:
        st, checks = status_plan.get(s["name"], ("candidate", {}))
        fid = None
        if st == "operating":
            d = dongs[s["dong"]]
            fid = _facility(con, kind="room", name=f"{d['name']} 늦은 시간 돌봄방", dong=s["dong"], lat=s["lat"], lon=s["lon"],
                            address=f"{s['name']} (가상)", phone=f"031-000-{2001 + len(room_ids)}", age_min_m=None, age_max_m=None,
                            target="elem", hours_json=json.dumps(ROOM_HOURS), per_teacher=10, room_capacity=15, fee_per_hour=0,
                            bookable=1, status="operating", status_label="시범 돌봄방(가정) · 이용료 검토 중", source_ref=None)
            room_ids.append(fid)
        sid = con.execute("""INSERT INTO spaces(kind,name,dong,lat,lon,floor,area,elevator,source,source_note,status,checks_json,memo,facility_id,updated_at)
                             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                          (s["kind"], s["name"], s["dong"], s["lat"], s["lon"], s["floor"], s["area"],
                           None if s["elevator"] is None else int(bool(s["elevator"])), s["source"], s["source_note"], st,
                           json.dumps(checks), "", fid, db.now_s())).lastrowid
        if fid:
            con.execute("UPDATE facilities SET source_ref=? WHERE id=?", (f"space:{sid}", fid))

    # 사용자
    _user(con, "city", "city", "안산시 여성보육과(데모)", demo=1)
    teacher_names = ["김보람", "이수정", "박민지", "최윤호"]
    fac_all = hub_ids + room_ids
    for i, fid in enumerate(fac_all):
        uname = f"teacher{i + 1}"
        _user(con, uname, "teacher", f"{teacher_names[i % 4]} 돌봄교사", facility_id=fid, demo=1)

    p1 = _user(con, "parent1", "parent", "정다은", home_dong=h1["dong"], phone="010-0000-0001", demo=1)
    p2_home = dongs[room_picks[0]["dong"]]["code"] if room_picks else h2["dong"]
    p2 = _user(con, "parent2", "parent", "한지훈", home_dong=p2_home, phone="010-0000-0002", demo=1)
    p3 = _user(con, "parent3", "parent", "오수빈", home_dong=h2["dong"], phone="010-0000-0003", demo=1)
    kids = {}

    def add_child(pid, name, birth, notes=""):
        cid = con.execute("INSERT INTO children(parent_id,name,birthdate,notes,created_at) VALUES(?,?,?,?,?)",
                          (pid, name, birth, notes, db.now_s())).lastrowid
        kids.setdefault(pid, []).append(cid)
        return cid

    add_child(p1, "정하윤", (today - dt.timedelta(days=4 * 365 + 120)).isoformat(), "땅콩 알레르기")
    add_child(p1, "정도윤", dt.date(today.year - 8, 8, 22).isoformat(), "")
    add_child(p2, "한서준", dt.date(today.year - 9, 5, 3).isoformat(), "천식 흡입기 지참")
    add_child(p3, "오지안", (today - dt.timedelta(days=590)).isoformat(), "낮잠 시 애착인형")

    # 배경 보호자(이용 기록용)
    facs = db.rows(con, "SELECT * FROM facilities WHERE bookable=1")
    pool: dict[int, list[tuple[dict, int, str]]] = {f["id"]: [] for f in facs}
    n = 0
    for f in facs:
        near = sorted(dongs.values(), key=lambda d: analysis._dist_km(d["res_lat"], d["res_lon"], f["lat"], f["lon"]))[:5]
        cnt = 34 if f["kind"] == "hub" else 22
        for _ in range(cnt):
            n += 1
            home = rng.choices(near, [5, 3, 2, 1, 1])[0]
            fam = rng.choice(FAMILY)
            pid = _user(con, f"user{n:03d}", "parent", fam + rng.choice(PARENT_GIVEN), home_dong=home["code"])
            kind = "elem" if f["target"] == "elem" else rng.choice(["infant", "preschool", "preschool"])
            birth = _birth_for(rng, kind, today)
            cid = add_child(pid, fam + rng.choice(GIVEN), birth)
            pool[f["id"]].append(({"id": pid}, cid, birth))
    # 데모 보호자도 풀에
    pool[hub_ids[0]].append(({"id": p1}, kids[p1][0], ""))
    if room_ids:
        pool[room_ids[0]].append(({"id": p2}, kids[p2][0], ""))
    pool[hub_ids[1]].append(({"id": p3}, kids[p3][0], ""))

    fc_cache = {f["id"]: analysis.forecast(f["lat"], f["lon"]) for f in facs if f["kind"] == "hub"}
    for k in range(-28, 3):
        day = today + dt.timedelta(days=k)
        for f in facs:
            generate_day(con, rng, f, day, pool[f["id"]], fc_cache.get(f["id"]))
    ensure_today_demo(con, rng)

    # 수요 등록
    rem = {d["code"]: d["remaining_gap"] for d in cov["dongs"]}
    codes = list(rem)
    weights = [rem[c] + 6 for c in codes]
    slots_all = ["weekday_18_20", "weekday_20_22", "night_22_07", "sat", "holiday"]
    for _ in range(160):
        c = rng.choices(codes, weights)[0]
        age = rng.choices(["elem", "preschool", "infant"], [45, 35, 20])[0]
        sl = rng.sample(slots_all, rng.randint(1, 3))
        if age != "elem" and "night_22_07" not in sl and rng.random() < .3:
            sl.append("night_22_07")
        created = db.now() - dt.timedelta(days=rng.randint(0, 60), hours=rng.randint(0, 23))
        con.execute("INSERT INTO demand_requests(parent_id,dong,age_group,slots,note,created_at) VALUES(NULL,?,?,?,?,?)",
                    (c, age, ",".join(sl), "", created.isoformat(timespec="seconds")))

    # 데모 보호자 알림·메시지
    th = care.thread_for(con, hub_ids[0], p1)
    t_hub1 = db.one(con, "SELECT id FROM users WHERE username='teacher1'")["id"]
    con.execute("INSERT INTO messages(thread_id,sender_id,body,created_at,read_by_parent,read_by_facility) VALUES(?,?,?,?,1,1)",
                (th, p1, "오늘 하윤이 저녁은 집에서 먹고 갑니다. 22시쯤 데리러 갈게요.", (db.now() - dt.timedelta(days=1, hours=2)).isoformat()))
    con.execute("INSERT INTO messages(thread_id,sender_id,body,created_at,read_by_parent,read_by_facility) VALUES(?,?,?,?,0,1)",
                (th, t_hub1, "네, 알겠습니다. 하윤이 오늘 블록놀이 잘 하고 있어요. 땅콩 들어간 간식은 빼 두었습니다.",
                 (db.now() - dt.timedelta(days=1, hours=1)).isoformat()))
    con.execute("INSERT INTO notifications(user_id,kind,title,body,link,created_at) VALUES(?,?,?,?,?,?)",
                (p1, "info", "안산시 24시간 돌봄 서비스에 오신 것을 환영해요", "가까운 거점·돌봄방을 찾고, 예약하고, 입실·귀가 알림을 받을 수 있어요.",
                 "#/parent", (db.now() - dt.timedelta(days=3)).isoformat()))
    con.commit()


def _slot_time(day: dt.date, hour: int, half: bool = False) -> dt.datetime:
    base = dt.datetime.combine(day, dt.time())
    return base + dt.timedelta(hours=hour, minutes=30 if half else 0)


def _poisson(rng: random.Random, lam: float) -> int:
    lam = max(0.0, lam)
    l, k, p = math.exp(-lam), 0, 1.0
    while True:
        p *= rng.random()
        if p < l:
            return k
        k += 1


def generate_day(con, rng: random.Random, f: dict, day: dt.date, pool: list, fc: dict | None, only_types=None) -> None:
    """하루치 예약을 만든다(정원 초과 시 실패 기록이 남는다)."""
    from .holidays import day_type
    dtp = day_type(day)
    plans: list[tuple[dt.datetime, dt.datetime]] = []
    if f["kind"] == "hub" and fc:
        t = "weekday" if dtp == "weekday" else "holiday"
        parts = fc[t]["parts"]
        lam = {"late": parts["late"][20] * .95, "night": parts["night"][2] * 1.0, "early": parts["early"][6] * .8,
               "day": parts["day"][12] * .9 if t == "holiday" else 0, "daytime": 1.3 if t == "weekday" else 0}
        for kind, l in lam.items():
            if only_types and kind not in only_types:
                continue
            for _ in range(_poisson(rng, l)):
                if kind == "late":
                    s = _slot_time(day, 19, rng.random() < .6)
                    eh = rng.choices([20, 21, 22, 23, 24, 25], [26, 24, 20, 14, 9, 5])[0]
                    e = _slot_time(day, eh, rng.random() < .5)
                elif kind == "night":
                    sh = rng.choices([17, 18, 19, 20, 21, 22, 23], [14, 15, 10, 9, 20, 21, 5])[0]
                    s = _slot_time(day, sh, rng.random() < .3)
                    e = min(_slot_time(day, 31, rng.random() < .5), s + dt.timedelta(hours=13))
                elif kind == "early":
                    s = _slot_time(day, rng.choice([5, 5, 6]), rng.random() < .5)
                    e = _slot_time(day, 8)
                    if s >= e:
                        continue
                elif kind == "day":
                    s = _slot_time(day, rng.choice([8, 8, 9]), rng.random() < .3)
                    e = _slot_time(day, rng.choice([17, 18, 18, 19]))
                else:  # 평일 낮 시간제 이용
                    sh = rng.choice([10, 11, 13, 14, 15])
                    s = _slot_time(day, sh)
                    e = s + dt.timedelta(hours=rng.choice([2, 3, 4]))
                plans.append((s, e))
    elif f["kind"] == "room":
        if dtp == "weekday":
            for _ in range(_poisson(rng, 9.5)):
                s = _slot_time(day, 18, rng.random() < .25)
                e = _slot_time(day, rng.choices([20, 21, 22], [3, 4, 5])[0], False)
                plans.append((s, e))
        elif dtp == "sat":
            for _ in range(_poisson(rng, 7)):
                sh = rng.choice([10, 11, 13, 14])
                s = _slot_time(day, sh)
                e = min(_slot_time(day, 20), s + dt.timedelta(hours=rng.choice([3, 4, 6])))
                plans.append((s, e))
    now = db.now()
    for s, e in plans:
        rng.shuffle(pool)
        for parent, cid, _birth in pool:
            if parent["id"] and db.one(con, "SELECT 1 FROM users WHERE id=? AND demo=1", (parent["id"],)) and s > now:
                continue  # 데모 계정의 미래 예약은 따로 만든다
            try:
                r = care.create_reservation(con, parent, f["id"], cid, care.fmt_dt(s), care.fmt_dt(e), quiet=True,
                                            now=min(now, s - dt.timedelta(hours=rng.randint(3, 72))))
            except care.BookingError as ex:
                if ex.code == "full":
                    break
                continue
            _settle(con, rng, r["id"], s, e, now)
            break


def _settle(con, rng: random.Random, rid: int, s: dt.datetime, e: dt.datetime, now: dt.datetime) -> None:
    if e <= now:
        x = rng.random()
        if x < .05:
            con.execute("UPDATE reservations SET status='no_show' WHERE id=?", (rid,))
        elif x < .09:
            con.execute("UPDATE reservations SET status='cancelled', cancelled_at=? WHERE id=?", (care.fmt_dt(s - dt.timedelta(hours=5)), rid))
        else:
            ci = s + dt.timedelta(minutes=rng.randint(-5, 12))
            co = e + dt.timedelta(minutes=rng.randint(-25, 10))
            con.execute("UPDATE reservations SET status='checked_out', checkin_at=?, checkout_at=?, checkout_note='귀가 확인 코드 일치' WHERE id=?",
                        (ci.isoformat(timespec="seconds"), co.isoformat(timespec="seconds"), rid))
    elif s <= now:
        ci = s + dt.timedelta(minutes=rng.randint(0, 10))
        con.execute("UPDATE reservations SET status='checked_in', checkin_at=? WHERE id=?", (min(ci, now).isoformat(timespec="seconds"), rid))
    elif rng.random() < .04:
        con.execute("UPDATE reservations SET status='cancelled', cancelled_at=? WHERE id=?", (now.isoformat(timespec="seconds"), rid))


def ensure_today_demo(con, rng: random.Random | None = None) -> None:
    """오늘 날짜 기준 시연 데이터: 지금 입실 중인 아이, 곧 올 아이, 데모 보호자의 오늘 예약."""
    rng = rng or random.Random()
    today = dt.date.today()
    if db.get_setting(con, "demo_today") == today.isoformat():
        return
    now = db.now()
    hubs = db.rows(con, "SELECT * FROM facilities WHERE kind='hub' AND status='operating' ORDER BY id")
    others = db.rows(con, "SELECT u.id, c.id cid FROM users u JOIN children c ON c.parent_id=u.id WHERE u.role='parent' AND u.demo=0")
    rng.shuffle(others)
    oi = 0
    for f in hubs:
        # 지금 입실 중 2명 + 30분·90분 뒤 예약
        slot = now.replace(minute=0 if now.minute < 30 else 30, second=0)
        for start_off, dur in ((-60, 3), (-30, 4), (30, 3), (90, 4)):
            for _ in range(8):
                if oi >= len(others):
                    break
                p = others[oi]
                oi += 1
                s = slot + dt.timedelta(minutes=start_off)
                e = s + dt.timedelta(hours=dur)
                try:
                    r = care.create_reservation(con, {"id": p["id"]}, f["id"], p["cid"], care.fmt_dt(s), care.fmt_dt(e), quiet=True,
                                                now=s - dt.timedelta(hours=6))
                except care.BookingError:
                    continue
                _settle(con, rng, r["id"], s, e, now)
                break
    # 데모 보호자 예약
    p1 = db.one(con, "SELECT id FROM users WHERE username='parent1'")
    if p1 and hubs:
        cid = db.one(con, "SELECT id FROM children WHERE parent_id=? ORDER BY id LIMIT 1", (p1["id"],))["id"]
        base = dt.datetime.combine(today, dt.time(19))
        if base < now + dt.timedelta(minutes=30):
            base = dt.datetime.combine(today + dt.timedelta(days=1), dt.time(19))
        for s, e in ((base, base + dt.timedelta(hours=3)), (base + dt.timedelta(days=2, minutes=30), base + dt.timedelta(days=2, hours=4))):
            try:
                care.create_reservation(con, {"id": p1["id"]}, hubs[0]["id"], cid, care.fmt_dt(s), care.fmt_dt(e), quiet=True,
                                        now=now)
            except care.BookingError:
                pass
    db.set_setting(con, "demo_today", today.isoformat())
    con.commit()
