"""운영 도메인: 시설 운영시간·정원, 예약 검증, 알림, 메시지."""
from __future__ import annotations

import datetime as dt
import json
import math
import secrets

from . import db, events, refdata
from .holidays import day_type

ACTIVE = ("booked", "checked_in")
STATUS_KO = {"booked": "예약됨", "checked_in": "입실", "checked_out": "귀가 완료", "cancelled": "취소", "no_show": "미이용"}
KIND_KO = {"hub": "24시간 거점 보육센터", "room": "늦은 시간 돌봄방", "timecare": "기존 시간제 보육"}
DAYTYPE_KO = {"weekday": "평일", "sat": "토요일", "holiday": "일·공휴일"}


class BookingError(Exception):
    def __init__(self, msg: str, code: str = "invalid"):
        super().__init__(msg)
        self.code = code


def parse_dt(s: str) -> dt.datetime:
    return dt.datetime.fromisoformat(s.replace("Z", ""))


def fmt_dt(d: dt.datetime) -> str:
    return d.isoformat(timespec="minutes")


def hm(minutes: int) -> str:
    h, m = divmod(minutes, 60)
    return f"{'다음 날 ' if h >= 24 else ''}{h % 24:02d}:{m:02d}"


# ── 시설 ────────────────────────────────────────────────
def facility_public(f: dict) -> dict:
    hours = json.loads(f["hours_json"])
    d = refdata.dong_by_code().get(f["dong"], {})
    out = {k: f[k] for k in ("id", "kind", "name", "dong", "lat", "lon", "address", "phone", "age_min_m", "age_max_m", "target",
                             "fee_per_hour", "bookable", "status", "status_label")}
    out["kind_label"] = KIND_KO[f["kind"]]
    out["dong_name"] = d.get("name", "")
    out["hours"] = {k: ({"start": v[0], "end": v[1], "label": f"{hm(v[0])}~{hm(v[1])}"} if v else None) for k, v in hours.items()}
    vals = list(hours.values())
    if vals and all(v == vals[0] for v in vals) and vals[0]:
        out["hours_text"] = f"매일 {hm(vals[0][0])}~{hm(vals[0][1])} (평일·휴일)"
    else:
        out["hours_text"] = " · ".join(f"{DAYTYPE_KO[k]} {hm(v[0])}~{hm(v[1])}" if v else f"{DAYTYPE_KO[k]} 휴무" for k, v in hours.items())
    out["staffing"] = json.loads(f["staffing_json"]) if f.get("staffing_json") else None
    out["per_teacher"] = f["per_teacher"]
    out["room_capacity"] = f["room_capacity"]
    return out


def windows(f: dict, start_day: dt.date, end_day: dt.date) -> list[tuple[dt.datetime, dt.datetime]]:
    """운영 구간(이어지는 구간은 합침)."""
    hours = json.loads(f["hours_json"])
    out = []
    d = start_day - dt.timedelta(days=1)
    while d <= end_day:
        w = hours.get(day_type(d))
        if w:
            base = dt.datetime.combine(d, dt.time())
            s, e = base + dt.timedelta(minutes=w[0]), base + dt.timedelta(minutes=w[1])
            if out and out[-1][1] >= s:
                out[-1] = (out[-1][0], max(out[-1][1], e))
            else:
                out.append((s, e))
        d += dt.timedelta(days=1)
    return out


def capacity_at(f: dict, t: dt.datetime) -> int:
    if f["kind"] == "hub":
        staffing = json.loads(f["staffing_json"])
        return int(math.floor(staffing[t.hour] * f["per_teacher"] + 1e-9))
    return int(f["room_capacity"] or 0)


def is_open(f: dict, s: dt.datetime, e: dt.datetime) -> bool:
    return any(ws <= s and e <= we for ws, we in windows(f, s.date(), e.date()))


def hour_slots(s: dt.datetime, e: dt.datetime) -> list[dt.datetime]:
    t = s.replace(minute=0, second=0)
    out = []
    while t < e:
        out.append(t)
        t += dt.timedelta(hours=1)
    return out


def occupancy(con, facility_id: int, s: dt.datetime, e: dt.datetime, exclude_id: int | None = None) -> dict[dt.datetime, int]:
    rs = db.rows(con, f"""SELECT id,start_at,end_at FROM reservations WHERE facility_id=? AND status IN {ACTIVE}
                          AND start_at < ? AND end_at > ?""", (facility_id, fmt_dt(e), fmt_dt(s)))
    occ = {t: 0 for t in hour_slots(s, e)}
    for r in rs:
        if exclude_id and r["id"] == exclude_id:
            continue
        rs_, re_ = parse_dt(r["start_at"]), parse_dt(r["end_at"])
        for t in occ:
            if rs_ < t + dt.timedelta(hours=1) and re_ > t:
                occ[t] += 1
    return occ


def availability(con, f: dict, date: dt.date) -> list[dict]:
    """해당 날짜의 시간대별 정원·예약·남은 자리. 거점은 07시~다음 날 07시."""
    if f["kind"] == "hub":
        s = dt.datetime.combine(date, dt.time(7))
        e = s + dt.timedelta(hours=24)
    else:
        ws = [w for w in windows(f, date, date) if w[0].date() == date]
        if not ws:
            return []
        s, e = ws[0][0].replace(minute=0), ws[0][1]
    occ = occupancy(con, f["id"], s, e)
    opened = windows(f, s.date(), e.date())
    out = []
    for t, n in occ.items():
        open_ = any(ws <= t < we for ws, we in opened)
        cap = capacity_at(f, t) if open_ else 0
        out.append({"start": fmt_dt(t), "hour": t.hour, "cap": cap, "booked": n, "left": max(0, cap - n), "open": open_})
    return out


# ── 아이 나이 ───────────────────────────────────────────
def age_months(birth: str, on: dt.date) -> int:
    b = dt.date.fromisoformat(birth)
    m = (on.year - b.year) * 12 + (on.month - b.month)
    if on.day < b.day:
        m -= 1
    return m


def school_grade(birth: str, on: dt.date) -> int:
    """초등 학년(취학 전 0 이하). 3월 학기 기준."""
    b = dt.date.fromisoformat(birth)
    school_year = on.year if on.month >= 3 else on.year - 1
    return school_year - b.year - 6


def age_label(birth: str, on: dt.date | None = None) -> str:
    on = on or dt.date.today()
    g = school_grade(birth, on)
    if 1 <= g <= 6:
        return f"초{g}"
    m = age_months(birth, on)
    if m < 36:
        return f"{m}개월"
    return f"만 {m // 12}세"


def child_fits(f: dict, birth: str, on: dt.date) -> tuple[bool, str]:
    if f["target"] == "elem":
        g = school_grade(birth, on)
        return (1 <= g <= 6), "초등학생(1~6학년)만 이용할 수 있어요. 영유아는 24시간 거점 보육센터를 이용해 주세요."
    m = age_months(birth, on)
    lo, hi = f["age_min_m"] or 0, f["age_max_m"] or 999
    if f["kind"] == "hub":
        ok = lo <= m and school_grade(birth, on) <= 0
    else:
        ok = lo <= m <= hi
    return ok, f"이 시설은 {lo}개월~{'취학 전' if f['kind'] == 'hub' else f'{hi}개월'} 아이가 이용할 수 있어요."


# ── 알림 ────────────────────────────────────────────────
def notify(con, user_id: int, kind: str, title: str, body: str = "", link: str = "") -> None:
    cur = con.execute("INSERT INTO notifications(user_id,kind,title,body,link,created_at) VALUES(?,?,?,?,?,?)",
                      (user_id, kind, title, body, link, db.now_s()))
    events.publish(user_id, "notification", {"id": cur.lastrowid, "kind": kind, "title": title, "body": body, "link": link,
                                             "created_at": db.now_s()})


def facility_staff(con, facility_id: int) -> list[int]:
    return [r["id"] for r in db.rows(con, "SELECT id FROM users WHERE role='teacher' AND facility_id=?", (facility_id,))]


def ping_staff(con, facility_id: int, kind: str = "roster") -> None:
    for uid in facility_staff(con, facility_id):
        events.publish(uid, kind, {"facility_id": facility_id})


# ── 예약 ────────────────────────────────────────────────
def create_reservation(con, parent: dict, facility_id: int, child_id: int, start: str, end: str, note: str = "",
                       quiet: bool = False, now: dt.datetime | None = None) -> dict:
    now = now or db.now()
    f = db.one(con, "SELECT * FROM facilities WHERE id=?", (facility_id,))
    if not f or f["status"] != "operating":
        raise BookingError("운영 중인 시설이 아닙니다.")
    if not f["bookable"]:
        raise BookingError("이 시설은 이 서비스에서 예약을 받지 않습니다.")
    child = db.one(con, "SELECT * FROM children WHERE id=? AND parent_id=? AND active=1", (child_id, parent["id"]))
    if not child:
        raise BookingError("아이 정보를 찾을 수 없습니다.")
    try:
        s, e = parse_dt(start), parse_dt(end)
    except ValueError:
        raise BookingError("시간 형식이 올바르지 않습니다.")
    if s.minute % 30 or e.minute % 30:
        raise BookingError("30분 단위로 예약해 주세요.")
    if e <= s:
        raise BookingError("끝나는 시간이 시작 시간보다 늦어야 합니다.")
    if s < now - dt.timedelta(minutes=30):
        raise BookingError("이미 지난 시간입니다.")
    if s > now + dt.timedelta(days=14):
        raise BookingError("예약은 14일 앞까지 받을 수 있습니다.")
    hours = (e - s).total_seconds() / 3600
    max_h = 13 if f["kind"] == "hub" else 12
    if hours > max_h:
        raise BookingError(f"한 번에 최대 {max_h}시간까지 예약할 수 있습니다.")
    ok, msg = child_fits(f, child["birthdate"], s.date())
    if not ok:
        raise BookingError(msg, "age")
    if not is_open(f, s, e):
        raise BookingError(f"운영시간이 아닙니다. ({facility_public(f)['hours_text']})", "closed")
    dup = db.one(con, f"""SELECT id FROM reservations WHERE child_id=? AND status IN {ACTIVE} AND start_at < ? AND end_at > ?""",
                 (child_id, fmt_dt(e), fmt_dt(s)))
    if dup:
        raise BookingError("같은 시간에 이 아이의 다른 예약이 있습니다.")
    occ = occupancy(con, facility_id, s, e)
    full = [t for t, n in occ.items() if n + 1 > capacity_at(f, t)]
    if full:
        con.execute("INSERT INTO booking_failures(facility_id,parent_id,start_at,end_at,reason,created_at) VALUES(?,?,?,?,?,?)",
                    (facility_id, parent["id"], fmt_dt(s), fmt_dt(e), "capacity", fmt_dt(now)))
        con.commit()
        t = full[0]
        raise BookingError(f"{t.hour:02d}~{(t.hour + 1) % 24:02d}시는 정원이 찼습니다. 다른 시간을 골라 주세요. "
                           "(정원이 차서 예약하지 못한 기록은 시의 교사 배치 근거로 쓰입니다)", "full")
    fee = int(round(hours * 2) / 2 * (f["fee_per_hour"] or 0))
    code = f"{secrets.randbelow(10000):04d}"
    cur = con.execute("""INSERT INTO reservations(facility_id,child_id,parent_id,start_at,end_at,status,fee,pickup_code,note,created_at)
                         VALUES(?,?,?,?,?,'booked',?,?,?,?)""",
                      (facility_id, child_id, parent["id"], fmt_dt(s), fmt_dt(e), fee, code, note[:300], fmt_dt(now)))
    rid = cur.lastrowid
    if not quiet:
        when = f"{s.month}/{s.day} {s:%H:%M}~{'다음 날 ' if e.date() > s.date() else ''}{e:%H:%M}"
        notify(con, parent["id"], "booking", "예약이 확정됐어요",
               f"{child['name']} · {f['name']} · {when} · 귀가 확인 코드 {code}", f"#/parent/reservations/{rid}")
        for uid in facility_staff(con, facility_id):
            notify(con, uid, "booking", "새 예약", f"{child['name']}({age_label(child['birthdate'], s.date())}) · {when}", "#/teacher")
        ping_staff(con, facility_id)
    return {"id": rid, "fee": fee, "pickup_code": code}


def reservation_view(r: dict) -> dict:
    s, e = parse_dt(r["start_at"]), parse_dt(r["end_at"])
    out = dict(r)
    out["status_label"] = STATUS_KO[r["status"]]
    out["hours"] = round((e - s).total_seconds() / 3600, 1)
    out["overnight"] = e.date() > s.date()
    if "child_birth" in r and r["child_birth"]:
        out["child_age"] = age_label(r["child_birth"], s.date())
    return out


def cancel_reservation(con, user: dict, rid: int) -> None:
    r = db.one(con, """SELECT r.*, c.name child_name, f.name fac_name FROM reservations r JOIN children c ON c.id=r.child_id
                       JOIN facilities f ON f.id=r.facility_id WHERE r.id=?""", (rid,))
    if not r or r["parent_id"] != user["id"]:
        raise BookingError("예약을 찾을 수 없습니다.", "notfound")
    if r["status"] != "booked":
        raise BookingError("이미 입실했거나 끝난 예약은 취소할 수 없습니다.")
    con.execute("UPDATE reservations SET status='cancelled', cancelled_at=? WHERE id=?", (db.now_s(), rid))
    s = parse_dt(r["start_at"])
    for uid in facility_staff(con, r["facility_id"]):
        notify(con, uid, "cancel", "예약 취소", f"{r['child_name']} · {s.month}/{s.day} {s:%H:%M}", "#/teacher")
    ping_staff(con, r["facility_id"])


def check_in(con, teacher: dict, rid: int) -> dict:
    r = _staff_reservation(con, teacher, rid)
    if r["status"] != "booked":
        raise BookingError("예약 상태에서만 입실 처리할 수 있습니다.")
    t = db.now()
    con.execute("UPDATE reservations SET status='checked_in', checkin_at=? WHERE id=?", (t.isoformat(timespec="seconds"), rid))
    notify(con, r["parent_id"], "checkin", f"{r['child_name']} 입실 확인",
           f"{t:%H:%M}에 {r['fac_name']}에 들어왔어요. 담당: {teacher['name']}", f"#/parent/reservations/{rid}")
    ping_staff(con, r["facility_id"])
    return {"ok": True}


def check_out(con, teacher: dict, rid: int, code: str, override: str = "") -> dict:
    r = _staff_reservation(con, teacher, rid)
    if r["status"] != "checked_in":
        raise BookingError("입실한 아이만 귀가 처리할 수 있습니다.")
    if (code or "").strip() != r["pickup_code"]:
        if not override.strip():
            raise BookingError("귀가 확인 코드가 맞지 않습니다. 보호자 신분을 따로 확인했다면 확인 방법을 적어 주세요.", "code")
        note = f"코드 불일치 · 대체 확인: {override.strip()[:100]}"
    else:
        note = "귀가 확인 코드 일치"
    t = db.now()
    con.execute("UPDATE reservations SET status='checked_out', checkout_at=?, checkout_note=? WHERE id=?",
                (t.isoformat(timespec="seconds"), note, rid))
    notify(con, r["parent_id"], "checkout", f"{r['child_name']} 귀가 완료",
           f"{t:%H:%M}에 보호자에게 인계했어요. ({note})", f"#/parent/reservations/{rid}")
    ping_staff(con, r["facility_id"])
    return {"ok": True}


def _staff_reservation(con, teacher: dict, rid: int) -> dict:
    r = db.one(con, """SELECT r.*, c.name child_name, f.name fac_name FROM reservations r JOIN children c ON c.id=r.child_id
                       JOIN facilities f ON f.id=r.facility_id WHERE r.id=?""", (rid,))
    if not r or r["facility_id"] != teacher["facility_id"]:
        raise BookingError("예약을 찾을 수 없습니다.", "notfound")
    return r


def sweep(con) -> int:
    """예약 시작 1시간이 지나도 입실하지 않으면 미이용 처리, 1시간 전 알림."""
    now = db.now()
    n = 0
    late = db.rows(con, """SELECT r.id,r.parent_id,r.facility_id,r.start_at,c.name child_name,f.name fac_name FROM reservations r
                           JOIN children c ON c.id=r.child_id JOIN facilities f ON f.id=r.facility_id
                           WHERE r.status='booked' AND r.start_at < ?""", (fmt_dt(now - dt.timedelta(hours=1)),))
    for r in late:
        con.execute("UPDATE reservations SET status='no_show' WHERE id=?", (r["id"],))
        s = parse_dt(r["start_at"])
        notify(con, r["parent_id"], "noshow", "미이용 처리됐어요",
               f"{r['child_name']} · {r['fac_name']} {s.month}/{s.day} {s:%H:%M} 예약에 입실 기록이 없어 미이용으로 처리했어요.", "#/parent/reservations")
        ping_staff(con, r["facility_id"])
        n += 1
    soon = db.rows(con, """SELECT r.id,r.parent_id,r.start_at,r.pickup_code,c.name child_name,f.name fac_name FROM reservations r
                           JOIN children c ON c.id=r.child_id JOIN facilities f ON f.id=r.facility_id
                           WHERE r.status='booked' AND r.reminded=0 AND r.start_at BETWEEN ? AND ?""",
                   (fmt_dt(now), fmt_dt(now + dt.timedelta(hours=1))))
    for r in soon:
        s = parse_dt(r["start_at"])
        notify(con, r["parent_id"], "reminder", "곧 예약 시간이에요",
               f"{r['child_name']} · {r['fac_name']} {s:%H:%M} · 귀가 확인 코드 {r['pickup_code']}", f"#/parent/reservations/{r['id']}")
        con.execute("UPDATE reservations SET reminded=1 WHERE id=?", (r["id"],))
    con.commit()
    return n


# ── 메시지 ──────────────────────────────────────────────
def thread_for(con, facility_id: int, parent_id: int) -> int:
    r = db.one(con, "SELECT id FROM threads WHERE facility_id=? AND parent_id=?", (facility_id, parent_id))
    if r:
        return r["id"]
    return con.execute("INSERT INTO threads(facility_id,parent_id,created_at) VALUES(?,?,?)", (facility_id, parent_id, db.now_s())).lastrowid


def send_message(con, user: dict, thread_id: int, body: str) -> dict:
    body = (body or "").strip()
    if not body:
        raise BookingError("메시지를 입력해 주세요.")
    th = db.one(con, "SELECT t.*, f.name fac_name FROM threads t JOIN facilities f ON f.id=t.facility_id WHERE t.id=?", (thread_id,))
    if not th or not can_access_thread(user, th):
        raise BookingError("대화를 찾을 수 없습니다.", "notfound")
    is_parent = user["role"] == "parent"
    cur = con.execute("""INSERT INTO messages(thread_id,sender_id,body,created_at,read_by_parent,read_by_facility)
                         VALUES(?,?,?,?,?,?)""", (thread_id, user["id"], body[:1000], db.now_s(), int(is_parent), int(not is_parent)))
    msg = {"id": cur.lastrowid, "thread_id": thread_id, "sender_id": user["id"], "sender_name": user["name"], "body": body[:1000],
           "created_at": db.now_s()}
    if is_parent:
        for uid in facility_staff(con, th["facility_id"]):
            events.publish(uid, "message", msg)
            notify(con, uid, "message", f"{user['name']} 보호자 메시지", body[:80], f"#/teacher/messages/{thread_id}")
    else:
        events.publish(th["parent_id"], "message", msg)
        notify(con, th["parent_id"], "message", f"{th['fac_name']} 돌봄교사 메시지", body[:80], f"#/parent/messages/{thread_id}")
    return msg


def can_access_thread(user: dict, th: dict) -> bool:
    if user["role"] == "parent":
        return th["parent_id"] == user["id"]
    if user["role"] == "teacher":
        return th["facility_id"] == user["facility_id"]
    return False
