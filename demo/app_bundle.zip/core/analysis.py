"""분석 엔진.

1) 데이터셋 찾기·검증  (실제 파일 우선, 없으면 가상 데이터)
2) 기본 집계(동별 지표, 시간대 분포, 시설·공급, 공실 블록, 거주 격자) -> 메모리 캐시 + processed/base.json
3) 요청마다 바뀌는 계산(가중치·반경·거점 선택에 따라)
   - 동별 수요·공급·공백 (그림 1)
   - 거점 후보 순위 + 시 기준 비교 (그림 2)
   - 시간대별 예상 이용 (그림 3)
   - 거점 커버리지와 남는 공백, 귀가 시각 분포 (그림 4)
   - 공간 후보 점수 (그림 5)

계산식은 기획서 9.2를 따른다. 통신 데이터에는 '부모'가 없으므로 20~40대(AGE_GRP 03~05) 이동을 대신 쓴다.
"""
from __future__ import annotations

import datetime as dt
import json
import math
import os
import re
import threading
from pathlib import Path

from . import geo, refdata
from .holidays import is_rest_day

DATA = refdata.DATA
RAW, PUBLIC, PROCESSED = DATA / "raw", DATA / "public", DATA / "processed"
TARGET_AGES = {"03", "04", "05"}
NIGHT_DEP_HOURS = list(range(17, 24)) + list(range(0, 6))      # 9.2 야간 출근: 출발 17~23시, 0~5시
LATE_RET_HOURS = [22, 23] + list(range(0, 8))                  # 9.2 심야 귀가: 도착 22~23시, 0~7시
COMPONENTS = [
    ("night", "야간 출근", "DS-010"),
    ("late", "심야 귀가", "DS-012"),
    ("hol", "휴일 출근", "DS-002"),
    ("sandan", "산단 통근 부모 거주", "DS-083"),
]

DATASETS = [
    {"id": "DS-010", "name": "유출인구_이동목적별 성연령(행정동)", "table": "GG_PURPOSE_SEXAGE_ADMI_OUTFLOW", "kind": "raw",
     "pattern": r"^T9_GG_PURPOSE_SEXAGE_ADMI_OUTFLOW_(\d{6})_4127(-\d+)?\.csv$", "open": True,
     "required": ["ETL_YMD", "O_TIME_CD", "O_ADMI_CD", "PURPOSE", "SEX_CD", "AGE_GRP", "CNT"], "forbid": ["TRANS_GB"],
     "use": "밤에 출근하러 나가는 부모 세대(이동목적=출근)", "unit": "행정동, 1시간, 10세 성연령"},
    {"id": "DS-012", "name": "유입인구_이동목적별 성연령(행정동)", "table": "GG_PURPOSE_SEXAGE_ADMI_INFLOW", "kind": "raw",
     "pattern": r"^T5_GG_PURPOSE_SEXAGE_ADMI_INFLOW_(\d{6})_4127(-\d+)?\.csv$", "open": True,
     "required": ["ETL_YMD", "D_TIME_CD", "D_ADMI_CD", "PURPOSE", "SEX_CD", "AGE_GRP", "CNT"], "forbid": ["TRANS_GB"],
     "use": "밤늦게·새벽에 귀가하는 부모 세대(이동목적=귀가)", "unit": "행정동, 1시간, 10세 성연령"},
    {"id": "DS-002", "name": "유출인구_이동목적·수단·체류시간(행정동)", "table": "GG_PURPOSE_TRANS_SEXAGE_DURATION_ADMI_OUTFLOW", "kind": "raw",
     "pattern": r"^T27_GG_PURPOSE_TRANS_SEXAGE_DURATION_ADMI_OUTFLOW_(\d{6})_4127(-\d+)?\.csv$", "open": True,
     "required": ["ETL_YMD", "DOW", "O_TIME_CD", "O_ADMI_CD", "PURPOSE", "DURATION", "AGE_GRP", "CNT"], "forbid": [],
     "use": "휴일 출근, 근무(체류) 시간", "unit": "행정동, 요일"},
    {"id": "DS-083", "name": "통근통계", "table": "GYEONGGI_WORK_STAT", "kind": "raw",
     "pattern": r"^GYEONGGI_WORK_STAT_(\d{6})\.csv$", "open": False,
     "required": ["BS_YR_MON", "BS_HCD", "W_HCD", "TOT_CNT"], "forbid": [],
     "use": "산단 직장인이 사는 동 (내부 집계 결과만 사용)", "unit": "행정동(자택·직장)"},
    {"id": "DS-048", "name": "가맹점 정보(대민용)", "table": "tbsh_gyeonggi_mer_s", "kind": "raw", "months": 3,
     "pattern": r"^tbsh_gyeonggi_mer_s_(\d{6})\.csv$", "open": True,
     "required": ["ta_ym", "admi_cty_no", "blk_cd", "mer_cnt", "stop_cnt", "close_cnt"], "forbid": [],
     "use": "(확장) 휴업·해지가 많은 블록 = 상가 공실 후보", "unit": "블록, 월별"},
    {"id": "DS-031", "name": "생활인구_50m 셀", "table": "GG_50CELL_LIVEPOP", "kind": "raw", "optional": True,
     "pattern": r"^T3_GG_50CELL_LIVEPOP_(\d{6})_4127(-\d+)?\.csv$", "open": False,
     "required": ["ADMI_CD", "UTMK_X", "UTMK_Y", "TIME_CD"], "forbid": [],
     "use": "(선택) 후보 반경 안 부모 세대 거주 - 없으면 주거 중심 근사 격자 사용", "unit": "50m 격자"},
    {"id": "PUB-CC", "name": "어린이집 정보공개포털 기본정보", "kind": "public", "file": "childcare_centers.csv", "open": True,
     "required": ["crname", "crtypename", "crstatusname", "la", "lo", "crcapat", "crspec"], "forbid": [],
     "use": "시립어린이집 위치·정원, 운영 형태(야간연장·24시간), 문 닫은 어린이집", "unit": "시설"},
    {"id": "PUB-SGIS", "name": "SGIS 행정동 인구", "kind": "public", "file": "sgis_population.csv", "open": True,
     "required": ["adm_cd", "tot_ppltn", "age_0_5", "age_6_11", "age_20_49"], "forbid": [],
     "use": "영유아·초등 아동 수", "unit": "행정동"},
    {"id": "PUB-CARE", "name": "돌봄시설 목록(다함께돌봄·지역아동센터)", "kind": "public", "file": "care_facilities.csv", "open": True,
     "required": ["fclty_type", "fclty_nm", "lat", "lon", "close_tm", "capacity"], "forbid": [],
     "use": "늦은 시간 돌봄 공급(운영 종료 시각)", "unit": "시설"},
    {"id": "PUB-IDLE", "name": "공공 유휴공간 목록", "kind": "public", "file": "public_idle_spaces.csv", "open": True,
     "required": ["space_nm", "space_type", "lat", "lon", "floor", "area_m2"], "forbid": [],
     "use": "(확장) 돌봄방 공간 후보", "unit": "공간"},
    {"id": "REF-BLK", "name": "카드 블록 좌표", "kind": "public", "file": "card_blocks.csv", "open": True,
     "required": ["blk_cd", "lat", "lon"], "forbid": [],
     "use": "DS-048 블록코드를 지도 위치로 연결", "unit": "블록"},
]


# ─────────────────────────────────────────────────────────────
# 1) 데이터셋 찾기·검증
# ─────────────────────────────────────────────────────────────
def _find(spec: dict) -> tuple[list[Path], bool]:
    if spec["kind"] == "public":
        real = PUBLIC / spec["file"]
        if real.exists():
            return [real], False
        v = PUBLIC / "virtual" / spec["file"]
        return ([v] if v.exists() else []), True
    pat = re.compile(spec["pattern"])
    for folder, virtual in ((RAW, False), (RAW / "virtual", True)):
        if not folder.exists():
            continue
        files = [p for p in folder.iterdir() if p.is_file() and pat.match(p.name)]
        if not files:
            continue
        months = sorted({pat.match(p.name).group(1) for p in files})
        keep = set(months[-spec.get("months", 1):])
        return sorted(p for p in files if pat.match(p.name).group(1) in keep), virtual
    return [], True


def _header(path: Path) -> list[str]:
    raw = path.open("rb").readline()
    for enc in ("utf-8-sig", "cp949"):
        try:
            return [h.strip() for h in raw.decode(enc).strip().split(",")]
        except UnicodeDecodeError:
            continue
    return []


def registry() -> list[dict]:
    out = []
    for spec in DATASETS:
        files, virtual = _find(spec)
        item = {k: spec.get(k) for k in ("id", "name", "table", "open", "use", "unit", "optional")}
        item.update({"files": [p.name for p in files], "virtual": virtual if files else None, "status": "ok", "problems": []})
        if not files:
            item["status"] = "optional-missing" if spec.get("optional") else "missing"
        else:
            hdr = _header(files[0])
            miss = [c for c in spec["required"] if c not in hdr]
            bad = [c for c in spec["forbid"] if c in hdr]
            if miss:
                item["problems"].append(f"필수 컬럼 없음: {', '.join(miss)}")
            if bad:
                item["problems"].append(f"다른 테이블로 보임({', '.join(bad)} 컬럼 존재) - 인벤토리 Q-01 참고")
            if item["problems"]:
                item["status"] = "error"
            m = re.findall(r"(\d{6})", " ".join(p.name for p in files))
            item["period"] = f"{min(m)}~{max(m)}" if m else ""
        item["_paths"] = files
        out.append(item)
    return out


def _rows(reg: dict, ds_id: str):
    item = next(r for r in reg if r["id"] == ds_id)
    if item["status"] != "ok":
        return
    for p in item["_paths"]:
        yield from refdata.read_csv(p)


# ─────────────────────────────────────────────────────────────
# 2) 기본 집계
# ─────────────────────────────────────────────────────────────
def _hhmm(s: str) -> float:
    h, m = s.split(":")
    return int(h) + int(m) / 60


def _build_grid(dongs: list[dict], step_km: float = 0.2) -> list[list]:
    """동 경계 안 격자점 + 주거 중심 가중치(동별 합=1). DS-031을 받으면 실제 거주인구로 대체한다."""
    pts = []
    for d in dongs:
        x0, y0, x1, y1 = geo.geometry_bbox(d["geometry"])
        dlat = step_km / 111.0
        dlon = step_km / (111.32 * math.cos(math.radians(d["lat"])))
        cell = []
        lat = y0 + dlat / 2
        while lat < y1:
            lon = x0 + dlon / 2
            while lon < x1:
                if geo.point_in_geometry(lon, lat, d["geometry"]):
                    dy = (lat - d["res_lat"]) * 111.0
                    dx = (lon - d["res_lon"]) * 88.55
                    w = math.exp(-(dx * dx + dy * dy) / (2 * d["res_sigma"] ** 2))
                    cell.append([round(lat, 5), round(lon, 5), w])
                lon += dlon
            lat += dlat
        if not cell:
            cell = [[d["res_lat"], d["res_lon"], 1.0]]
        s = sum(c[2] for c in cell) or 1
        for c in cell:
            pts.append([c[0], c[1], d["code"], c[2] / s])
    return pts


def build_base() -> dict:
    reg = registry()
    dongs = refdata.dongs()
    codes = {d["code"] for d in dongs}
    z24 = lambda: [0.0] * 24  # noqa: E731
    dep = {"weekday": {c: z24() for c in codes}, "holiday": {c: z24() for c in codes}}
    ret = {"weekday": {c: z24() for c in codes}, "holiday": {c: z24() for c in codes}}
    ret3040 = {c: z24() for c in codes}
    days = {"weekday": set(), "holiday": set()}

    def daytype(ymd: str) -> str:
        d = dt.date(int(ymd[:4]), int(ymd[4:6]), int(ymd[6:8]))
        return "holiday" if is_rest_day(d) else "weekday"

    for r in _rows(reg, "DS-010"):
        if r["PURPOSE"] != "1" or r["AGE_GRP"] not in TARGET_AGES or r["O_ADMI_CD"] not in codes:
            continue
        t = daytype(r["ETL_YMD"])
        days[t].add(r["ETL_YMD"])
        dep[t][r["O_ADMI_CD"]][int(r["O_TIME_CD"])] += float(r["CNT"])
    days_in = {"weekday": set(), "holiday": set()}
    for r in _rows(reg, "DS-012"):
        if r["PURPOSE"] != "0" or r["AGE_GRP"] not in TARGET_AGES or r["D_ADMI_CD"] not in codes:
            continue
        t = daytype(r["ETL_YMD"])
        days_in[t].add(r["ETL_YMD"])
        h = int(r["D_TIME_CD"])
        ret[t][r["D_ADMI_CD"]][h] += float(r["CNT"])
        if t == "weekday" and r["AGE_GRP"] in ("04", "05"):
            ret3040[r["D_ADMI_CD"]][h] += float(r["CNT"])
    for t in ("weekday", "holiday"):
        n_out, n_in = max(1, len(days[t])), max(1, len(days_in[t]))
        for c in codes:
            dep[t][c] = [v / n_out for v in dep[t][c]]
            ret[t][c] = [v / n_in for v in ret[t][c]]
    n_in_wd = max(1, len(days_in["weekday"]))
    ret3040 = {c: [v / n_in_wd for v in arr] for c, arr in ret3040.items()}

    # DS-002 휴일(토·일) 출근, 야간 출근의 평균 체류시간
    hol_dep = {c: 0.0 for c in codes}
    wkend_days, dur_sum, dur_w = set(), {c: 0.0 for c in codes}, {c: 0.0 for c in codes}
    for r in _rows(reg, "DS-002"):
        if r["PURPOSE"] != "1" or r["AGE_GRP"] not in TARGET_AGES or r["O_ADMI_CD"] not in codes:
            continue
        cnt = float(r["CNT"])
        if r["DOW"] in ("토", "일"):
            wkend_days.add(r["ETL_YMD"])
            hol_dep[r["O_ADMI_CD"]] += cnt
        h = int(r["O_TIME_CD"])
        if h >= 17 or h <= 5:
            dur_sum[r["O_ADMI_CD"]] += cnt * (float(r["DURATION"]) - 15)  # 구간 끝값 -> 구간 중앙
            dur_w[r["O_ADMI_CD"]] += cnt
    hol_dep = {c: v / max(1, len(wkend_days)) for c, v in hol_dep.items()}
    night_dur = {c: (dur_sum[c] / dur_w[c] / 60 if dur_w[c] else None) for c in codes}

    # DS-083 산단 통근 부모 거주
    ind = refdata.read_csv(refdata.REF / "industrial.csv")
    sandan_w = {c for r in ind for c in r["W_HCD_LIST"].split("|")}
    sites = [{"name": r["SITE_NM"], "lat": float(r["REP_LAT"]), "lon": float(r["REP_LON"])} for r in ind]
    sandan = {c: 0.0 for c in codes}
    for r in _rows(reg, "DS-083"):
        home = r["BS_HCD"][:8]
        if home in codes and r["W_HCD"] in sandan_w:
            sandan[home] += float(r["TOT_CNT"] or 0)

    # SGIS 인구
    stat2code = {d["stat_cd"]: d["code"] for d in dongs}
    pop = {c: {"tot": 0, "kid": 0, "elem": 0, "adult": 0} for c in codes}
    for r in _rows(reg, "PUB-SGIS"):
        c = stat2code.get(r["adm_cd"]) or (r["adm_cd"][:8] if r["adm_cd"][:8] in codes else None)
        if c:
            pop[c] = {"tot": int(float(r["tot_ppltn"])), "kid": int(float(r["age_0_5"])),
                      "elem": int(float(r["age_6_11"])), "adult": int(float(r["age_20_49"]))}

    # 어린이집 / 돌봄시설 -> 동 배정(점-다각형) + 늦은 시간 공급
    supply = {c: 0.0 for c in codes}
    supply_n = {c: 0 for c in codes}
    centers, closed = [], []
    for r in _rows(reg, "PUB-CC"):
        lat, lon = float(r["la"]), float(r["lo"])
        d = refdata.locate_dong(lat, lon)
        if not d:
            continue
        spec = [s.strip() for s in (r.get("crspec") or "").split(",") if s.strip()]
        item = {"id": r.get("stcode"), "name": r["crname"], "type": r["crtypename"], "status": r["crstatusname"],
                "lat": lat, "lon": lon, "dong": d["code"], "dong_name": d["name"], "capacity": int(float(r["crcapat"] or 0)),
                "spec": spec, "closed_at": r.get("crabldt") or None,
                "floor": int(r["floor"]) if r.get("floor") else None, "area": float(r["area_m2"]) if r.get("area_m2") else None}
        if r["crstatusname"] == "폐지":
            closed.append(item)
            continue
        if r["crstatusname"] != "정상":
            continue
        centers.append(item)
        slots = min(item["capacity"] * 0.15, 15)  # 야간연장 실제 이용 정원(가정)
        units = 0.0
        if "야간연장" in spec:
            units += slots * 4.5        # 19:30~24:00
        if "24시간" in spec:
            units += slots * 12.0       # 19:30~다음 날 07:30
        if "휴일보육" in spec:
            units += slots * 3.0
        if units:
            supply[d["code"]] += units
            supply_n[d["code"]] += 1
    care = []
    for r in _rows(reg, "PUB-CARE"):
        lat, lon = float(r["lat"]), float(r["lon"])
        d = refdata.locate_dong(lat, lon)
        if not d:
            continue
        late_h = max(0.0, _hhmm(r["close_tm"]) - 19.5)
        care.append({"type": r["fclty_type"], "name": r["fclty_nm"], "lat": lat, "lon": lon, "dong": d["code"],
                     "close": r["close_tm"], "capacity": int(float(r["capacity"])), "late_hours": late_h})
        if late_h > 0:
            supply[d["code"]] += int(float(r["capacity"])) * late_h
            supply_n[d["code"]] += 1

    # DS-048 공실 후보 블록
    blk_pos = {}
    for r in _rows(reg, "REF-BLK"):
        blk_pos[r["blk_cd"]] = (float(r["lat"]), float(r["lon"]))
    agg = {}
    months = set()
    for r in _rows(reg, "DS-048"):
        months.add(r["ta_ym"])
        a = agg.setdefault(r["blk_cd"], {"dong": r["admi_cty_no"][:8], "by_m": {}})
        m = a["by_m"].setdefault(r["ta_ym"], {"n": 0, "stop": 0, "close": 0})
        m["n"] += int(float(r["mer_cnt"] or 0)) + int(float(r.get("entp_cnt") or 0))
        m["stop"] += int(float(r["stop_cnt"] or 0))
        m["close"] += int(float(r["close_cnt"] or 0))
    last = max(months) if months else None
    blocks = []
    for blk, a in agg.items():
        if blk not in blk_pos or a["dong"] not in codes or last not in a["by_m"]:
            continue
        n = a["by_m"][last]["n"]
        stop = a["by_m"][last]["stop"]
        close3 = sum(m["close"] for m in a["by_m"].values())
        rate = (stop + close3) / n if n else 0
        blocks.append({"blk_cd": blk, "dong": a["dong"], "lat": blk_pos[blk][0], "lon": blk_pos[blk][1],
                       "merchants": n, "stop": stop, "close_3m": close3, "vacancy_rate": round(rate, 3)})
    blocks.sort(key=lambda b: -b["vacancy_rate"])

    grid = _build_grid(dongs)

    per_dong = {}
    for d in dongs:
        c = d["code"]
        per_dong[c] = {
            "code": c, "name": d["name"], "gu": d["gu"], "lat": d["lat"], "lon": d["lon"],
            "res_lat": d["res_lat"], "res_lon": d["res_lon"], "area": d["area"],
            "night": sum(dep["weekday"][c][h] for h in NIGHT_DEP_HOURS),
            "late": sum(ret["weekday"][c][h] for h in LATE_RET_HOURS),
            "hol": hol_dep[c], "sandan": sandan[c],
            "night_work_hours": night_dur[c],
            "pop": pop[c], "supply_units": supply[c], "supply_count": supply_n[c],
        }
    base = {
        "built_at": dt.datetime.now().isoformat(timespec="seconds"),
        "virtual": any(r["virtual"] for r in reg if r["status"] == "ok"),
        "per_dong": per_dong, "dep": dep, "ret": ret, "ret3040": ret3040,
        "centers": centers, "closed_centers": closed, "care": care, "blocks": blocks,
        "sites": sites, "grid": grid,
        "days": {k: sorted(v) for k, v in days.items()},
        "registry": [{k: v for k, v in r.items() if k != "_paths"} for r in reg],
    }
    PROCESSED.mkdir(parents=True, exist_ok=True)
    slim = {k: v for k, v in base.items() if k not in ("grid",)}
    (PROCESSED / "base.json").write_text(json.dumps(slim, ensure_ascii=False, indent=1), encoding="utf-8")
    return base


_lock = threading.Lock()
_base: dict | None = None


def _load_or_build() -> dict:
    """CARE_BASE_JSON이 있으면(브라우저 체험판) 미리 집계한 결과를 읽고, 없으면 원천 파일에서 집계한다."""
    pre = os.environ.get("CARE_BASE_JSON")
    if pre and Path(pre).exists():
        return json.loads(Path(pre).read_text(encoding="utf-8"))
    return build_base()


def base() -> dict:
    global _base
    with _lock:
        if _base is None:
            _base = _load_or_build()
        return _base


def rebuild() -> dict:
    global _base
    with _lock:
        _base = _load_or_build()
        return _base


def dump_full(path: Path) -> None:
    """체험판용: 격자까지 포함한 집계 결과 전체를 JSON으로 저장."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(base(), ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


# ─────────────────────────────────────────────────────────────
# 3) 계산
# ─────────────────────────────────────────────────────────────
def _dist_km(lat1, lon1, lat2, lon2) -> float:
    return math.hypot((lat1 - lat2) * 111.0, (lon1 - lon2) * 88.55)


def catchment(lat: float, lon: float, r_km: float) -> dict[str, float]:
    """반경 r 안에 들어오는 동별 거주 비중."""
    out: dict[str, float] = {}
    for plat, plon, code, w in base()["grid"]:
        if _dist_km(lat, lon, plat, plon) <= r_km:
            out[code] = out.get(code, 0.0) + w
    return out


def _minmax(vals: list[float]) -> list[float]:
    lo, hi = min(vals), max(vals)
    return [(v - lo) / (hi - lo) if hi > lo else 0.5 for v in vals]


def _zs(vals: list[float]) -> list[float]:
    n = len(vals)
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / n) or 1
    return [(v - m) / sd for v in vals]


def normalize_weights(w: dict | None) -> dict:
    w = {k: max(0.0, float((w or {}).get(k, 1))) for k, _, _ in COMPONENTS}
    if sum(w.values()) == 0:
        w = {k: 1.0 for k in w}
    return w


def dong_table(weights: dict | None = None, registrations: dict | None = None) -> list[dict]:
    """그림 1: 동별 밤·휴일 돌봄 수요 지수와 늦은 시간 돌봄 공급 지수, 공백."""
    b = base()
    w = normalize_weights(weights)
    rows = list(b["per_dong"].values())
    maxes = {k: max(r[k] for r in rows) or 1 for k, _, _ in COMPONENTS}
    raw = [sum(w[k] * r[k] / maxes[k] for k, _, _ in COMPONENTS) / sum(w.values()) for r in rows]
    top = max(raw) or 1
    smax = max(r["supply_units"] for r in rows) or 1
    out = []
    for r, v in zip(rows, raw):
        demand = round(100 * v / top, 1)
        sup = round(100 * r["supply_units"] / smax, 1)
        out.append({
            "code": r["code"], "name": r["name"], "gu": r["gu"], "lat": r["lat"], "lon": r["lon"],
            "night": round(r["night"]), "late": round(r["late"]), "hol": round(r["hol"]), "sandan": round(r["sandan"]),
            "kids": r["pop"]["kid"], "elem": r["pop"]["elem"], "pop": r["pop"]["tot"],
            "night_work_hours": round(r["night_work_hours"], 1) if r["night_work_hours"] else None,
            "demand": demand, "supply": sup, "gap": round(demand - sup, 1),
            "supply_count": r["supply_count"],
            "registrations": (registrations or {}).get(r["code"], 0),
        })
    out.sort(key=lambda x: -x["gap"])
    return out


def _catch_sum(catch: dict, getter) -> float:
    pd = base()["per_dong"]
    return sum(f * getter(pd[c]) for c, f in catch.items())


def hub_candidates(weights: dict | None = None, radius_km: float = 1.0) -> dict:
    """그림 2: 시립어린이집별 반경 안 수요 점수 + 시 기준(인구·공단 인근) 비교."""
    b = base()
    w = normalize_weights(weights)
    wsum = sum(w.values())
    cands = [c for c in b["centers"] if c["type"] == "국공립"]
    rows = []
    for c in cands:
        catch = catchment(c["lat"], c["lon"], radius_km)
        comp = {k: _catch_sum(catch, lambda d, k=k: d[k]) for k, _, _ in COMPONENTS}
        pop_c = _catch_sum(catch, lambda d: d["pop"]["tot"])
        kids_c = _catch_sum(catch, lambda d: d["pop"]["kid"])
        site_d = min(_dist_km(c["lat"], c["lon"], s["lat"], s["lon"]) for s in b["sites"])
        rows.append({"id": c["id"], "name": c["name"], "dong": c["dong"], "dong_name": c["dong_name"], "lat": c["lat"], "lon": c["lon"],
                     "capacity": c["capacity"], "spec": c["spec"], "raw": comp, "pop": round(pop_c), "kids": round(kids_c),
                     "site_km": round(site_d, 2), "catch": {k: round(v, 3) for k, v in catch.items() if v >= 0.01}})
    if not rows:
        return {"candidates": [], "flags": []}
    for k, _, _ in COMPONENTS:
        top = max(r["raw"][k] for r in rows) or 1
        zz = _zs([r["raw"][k] for r in rows])
        for r, z in zip(rows, zz):
            # 후보 중 최댓값 대비 비율로 환산(가중치 합=100점)
            r.setdefault("points", {})[k] = round(100 * w[k] / wsum * r["raw"][k] / top, 1)
            r.setdefault("z", {})[k] = round(z, 2)
    for r in rows:
        r["score"] = round(sum(r["points"].values()), 1)
        r["z_sum"] = round(sum(w[k] * r["z"][k] for k, _, _ in COMPONENTS) / wsum * len(COMPONENTS), 2)
        r["raw"] = {k: round(v) for k, v in r["raw"].items()}
    pop_mm = _minmax([r["pop"] for r in rows])
    site_mm = _minmax([-r["site_km"] for r in rows])
    for r, p, s in zip(rows, pop_mm, site_mm):
        r["city_score"] = round(50 * p + 50 * s, 1)
    rows.sort(key=lambda r: -r["score"])
    for i, r in enumerate(rows):
        r["rank"] = i + 1
    for i, r in enumerate(sorted(rows, key=lambda r: -r["city_score"])):
        r["city_rank"] = i + 1
    n = len(rows)
    rho = 1 - 6 * sum((r["rank"] - r["city_rank"]) ** 2 for r in rows) / (n * (n * n - 1)) if n > 2 else None

    # 데이터가 가리키는 동에 시립이 없으면 '추가 지정 필요 지역'
    table = dong_table(weights)
    by_demand = sorted(table, key=lambda x: -x["gap"])[:8]
    pd = b["per_dong"]
    flags = []
    for t in by_demand:
        d = pd[t["code"]]
        near = min((_dist_km(d["res_lat"], d["res_lon"], c["lat"], c["lon"]) for c in cands), default=99)
        has_own = any(c["dong"] == t["code"] for c in cands)
        if not has_own and near > radius_km + 0.5:
            flags.append({"code": t["code"], "name": t["name"], "demand": t["demand"], "gap": t["gap"], "nearest_km": round(near, 2)})
    return {"candidates": rows, "spearman": round(rho, 2) if rho is not None else None, "flags": flags,
            "components": [{"key": k, "label": lab, "source": src} for k, lab, src in COMPONENTS], "weights": w, "radius_km": radius_km}


def _combine(catch: dict, series: dict) -> list[float]:
    out = [0.0] * 24
    for c, f in catch.items():
        arr = series.get(c)
        if arr:
            for h in range(24):
                out[h] += f * arr[h]
    return out


def _span(start: int, end: int) -> list[int]:
    """start 시부터 end 시 직전까지(자정 넘김 포함) 시각 목록."""
    hrs, h = [], start % 24
    while h != end % 24:
        hrs.append(h)
        h = (h + 1) % 24
        if len(hrs) > 24:
            break
    return hrs


DEFAULT_STAFFING = [1] * 7 + [1] * 11 + [2] * 5 + [1]   # 0~6시 1명, 7~17시 1명, 18~22시 2명, 23시 1명


def forecast(lat: float, lon: float, radius_km: float = 1.0, uptake_pct: float = 3.0,
             staffing: list[int] | None = None, per_teacher: float = 5.0) -> dict:
    """그림 3: 시간대별 예상 이용 아동 수.

    이용자 유형(20~40대 이동으로 추정):
      - 늦은 귀가: 기본보육(19:30) 이후 맡기고, 귀가 시각(20~02시 도착)에 찾아감
      - 야간 출근: 출근 시각(17~03시 출발)에 맡기고, 다음 날 08시(정규 등원)까지
      - 새벽 출근: 04~06시 출발 시 맡기고 08시까지
      - (휴일) 낮 근무: 06~10시 출발 시 맡기고 18시 귀가 무렵까지
    이용 아동 = 해당 이동 x 전환율(영유아 수/20~40대 인구 x 이용 의향 %)
    """
    b = base()
    catch = catchment(lat, lon, radius_km)
    kids = _catch_sum(catch, lambda d: d["pop"]["kid"])
    adults = _catch_sum(catch, lambda d: d["pop"]["adult"]) or 1
    conv = (kids / adults) * uptake_pct / 100
    res = {}
    for t in ("weekday", "holiday"):
        dep = _combine(catch, b["dep"][t])
        ret = _combine(catch, b["ret"][t])
        occ = [0.0] * 24
        parts = {"late": [0.0] * 24, "night": [0.0] * 24, "early": [0.0] * 24, "day": [0.0] * 24}
        for hr in [20, 21, 22, 23, 0, 1, 2]:
            for h in _span(19, hr):
                parts["late"][h] += ret[hr] * (0.5 if h == 19 else 1.0)
        for hd in [17, 18, 19, 20, 21, 22, 23, 0, 1, 2, 3]:
            for h in _span(hd, 8):
                parts["night"][h] += dep[hd]
        for he, f in ((4, 1.0), (5, 1.0), (6, 0.3)):   # 6시 출발은 대부분 등원 후 출근 가능 -> 일부만
            for h in _span(he, 8):
                parts["early"][h] += dep[he] * f
        if t == "holiday":   # 휴일엔 정규 어린이집이 쉬므로 낮 근무 부모 일부(60%)가 맡긴다고 가정
            for hd in [6, 7, 8, 9, 10]:
                for h in _span(hd, 18):
                    parts["day"][h] += dep[hd] * 0.6
        for k in parts:
            parts[k] = [v * conv for v in parts[k]]
        occ = [sum(parts[k][h] for k in parts) for h in range(24)]
        res[t] = {"total": [round(v, 1) for v in occ], "parts": {k: [round(v, 1) for v in arr] for k, arr in parts.items()}}
    staffing = staffing if staffing and len(staffing) == 24 else DEFAULT_STAFFING
    cap = [round(s * per_teacher, 1) for s in staffing]
    over = {t: [h for h in range(24) if res[t]["total"][h] > cap[h] + 1e-9] for t in res}
    need = {t: [math.ceil(v / per_teacher) if v > 0.2 else 0 for v in res[t]["total"]] for t in res}
    suggest = [max(1, need["weekday"][h], need["holiday"][h]) for h in range(24)]
    return {
        "hours": list(range(24)), "weekday": res["weekday"], "holiday": res["holiday"],
        "capacity": cap, "staffing": staffing, "per_teacher": per_teacher,
        "over": over, "teacher_hours": sum(staffing), "suggested_staffing": suggest,
        "suggested_teacher_hours": sum(suggest),
        "conv_pct": round(conv * 100, 3), "kids_in_radius": round(kids), "adults_in_radius": round(adults),
    }


def coverage(hubs: list[dict], threshold_km: float = 2.5, weights: dict | None = None,
             registrations: dict | None = None) -> dict:
    """거점에서 먼 수요 지역: 동별 거주 격자 중 거점에서 threshold 안에 드는 비중."""
    b = base()
    covered = {c: 0.0 for c in b["per_dong"]}
    wdist = {c: 0.0 for c in b["per_dong"]}
    for plat, plon, code, w in b["grid"]:
        dmin = min((_dist_km(plat, plon, h["lat"], h["lon"]) for h in hubs), default=99)
        if dmin <= threshold_km:
            covered[code] += w
        wdist[code] += w * dmin
    table = dong_table(weights, registrations)
    rows = []
    for t in table:
        cov = min(1.0, covered[t["code"]])
        remain = max(0.0, t["gap"]) * (1 - cov)
        rows.append({**t, "covered": round(cov, 3), "mean_km": round(wdist[t["code"]], 2), "remaining_gap": round(remain, 1)})
    rows.sort(key=lambda r: -r["remaining_gap"])
    return {"threshold_km": threshold_km, "hubs": hubs, "dongs": rows}


def return_profile(code: str) -> dict:
    """그림 4: 30~40대 평일 귀가 시각 분포(16~0시)와 기존 돌봄 종료 이후 비중."""
    arr = base()["ret3040"].get(code, [0.0] * 24)
    hours = [16, 17, 18, 19, 20, 21, 22, 23, 0]
    vals = [arr[h] for h in hours]
    tot = sum(vals) or 1
    pct = [round(100 * v / tot, 1) for v in vals]
    after20 = round(sum(pct[4:]), 1)
    return {"code": code, "name": base()["per_dong"][code]["name"], "hours": hours, "pct": pct, "after20_pct": after20,
            "care_end": {"어린이집 기본보육": "19:30", "늘봄학교(최대)": "20:00"}}


SPACE_KIND = {"vacant_store": "상가 공실", "public_idle": "공공 유휴공간", "closed_daycare": "문 닫은 어린이집"}


def score_spaces(spaces: list[dict], cov: dict, target: str = "elem", registrations: dict | None = None) -> list[dict]:
    """그림 5: 수요(동 공백, 40) + 접근성(도보 10분=800m 안 아동 수, 30) + 시설 적합도(층·면적·안전, 30)."""
    by_code = {d["code"]: d for d in cov["dongs"]}
    max_rem = max((d["remaining_gap"] for d in cov["dongs"]), default=1) or 1
    regs = registrations or {}
    max_reg = max(regs.values(), default=0) or 1
    out = []
    access_raw = []
    for s in spaces:
        catch = catchment(s["lat"], s["lon"], 0.8)
        kids = _catch_sum(catch, lambda d: d["pop"]["elem" if target == "elem" else "kid"])
        access_raw.append(kids)
    amax = max(access_raw, default=1) or 1
    for s, kids in zip(spaces, access_raw):
        d = by_code.get(s["dong"], {})
        rem = d.get("remaining_gap", 0)
        demand = 40 * (0.8 * rem / max_rem + 0.2 * regs.get(s["dong"], 0) / max_reg)
        access = 30 * kids / amax
        floor, area = s.get("floor"), s.get("area")
        elev = s.get("elevator")
        if floor is None:
            f_pts = 5
        elif floor <= 0:
            f_pts = 0
        elif floor == 1:
            f_pts = 10
        elif floor == 2:
            f_pts = 8 if elev else 6
        else:
            f_pts = 6 if elev else 2
        a_pts = 10 * min(1.0, (area or 0) / 66) if area else 4
        checks = s.get("checks") or {}
        checked = [v for v in (checks.get("fire"), checks.get("exit"), checks.get("insurance")) if v is not None]
        if checked:
            safe = 4 * (checks.get("fire") is True) + 3 * (checks.get("exit") is True) + 3 * (checks.get("insurance") is True)
            safe_est = False
        else:
            safe = {"closed_daycare": 7, "public_idle": 6, "vacant_store": 4}.get(s["kind"], 4)
            safe_est = True
        fit = f_pts + a_pts + safe
        out.append({**s, "kind_label": SPACE_KIND.get(s["kind"], s["kind"]), "dong_name": d.get("name", ""),
                    "remaining_gap": rem, "kids_800m": round(kids),
                    "scores": {"demand": round(demand, 1), "access": round(access, 1), "fit": round(fit, 1)},
                    "fit_detail": {"floor": f_pts, "area": round(a_pts, 1), "safety": safe, "safety_estimated": safe_est},
                    "total": round(demand + access + fit, 1)})
    out.sort(key=lambda x: -x["total"])
    return out


def initial_spaces() -> list[dict]:
    """데이터에서 공간 후보를 모은다(시드용). 상가 공실은 DS-048 휴업·해지 비율 상위 블록."""
    b = base()
    pd = b["per_dong"]
    out = []
    table = {t["code"]: t for t in dong_table()}
    hot = {c for c, t in table.items() if t["gap"] > 0}
    picked = 0
    seen_dong: dict[str, int] = {}
    for blk in b["blocks"]:
        if blk["dong"] not in hot or seen_dong.get(blk["dong"], 0) >= 2 or blk["merchants"] < 8:
            continue
        seen_dong[blk["dong"]] = seen_dong.get(blk["dong"], 0) + 1
        h = int(blk["blk_cd"])
        out.append({"kind": "vacant_store", "name": f"상가 공실 후보 · 블록 {blk['blk_cd']} ({pd[blk['dong']]['name']})",
                    "dong": blk["dong"], "lat": blk["lat"], "lon": blk["lon"],
                    "floor": 1 + (h % 3 == 0), "area": 48 + (h * 7) % 70, "elevator": None, "source": "DS-048",
                    "source_note": f"휴업 {blk['stop']}곳 + 최근 3개월 해지 {blk['close_3m']}곳 / 가맹점 {blk['merchants']}곳 "
                                   f"(비율 {round(blk['vacancy_rate'] * 100)}%) · 층·면적은 추정, 현장 확인 필요"})
        picked += 1
        if picked >= 10:
            break
    for c in b["closed_centers"]:
        out.append({"kind": "closed_daycare", "name": c["name"], "dong": c["dong"], "lat": c["lat"], "lon": c["lon"],
                    "floor": c["floor"], "area": c["area"], "elevator": None, "source": "PUB-CC",
                    "source_note": f"문 닫은 어린이집 (폐원일 {c['closed_at']}, 정원 {c['capacity']}명)"})
    reg = registry()
    for r in _rows(reg, "PUB-IDLE"):
        lat, lon = float(r["lat"]), float(r["lon"])
        d = refdata.locate_dong(lat, lon)
        if not d:
            continue
        out.append({"kind": "public_idle", "name": r["space_nm"], "dong": d["code"], "lat": lat, "lon": lon,
                    "floor": int(r["floor"]), "area": float(r["area_m2"]), "elevator": "엘리베이터 있음" in (r.get("note") or ""),
                    "source": "PUB-IDLE", "source_note": f"{r['space_type']} · {r.get('note', '')} · 관리: {r.get('owner', '')}"})
    return out


def dong_shapes_summary() -> list[dict]:
    return [{"code": d["code"], "name": d["name"], "gu": d["gu"], "lat": d["lat"], "lon": d["lon"],
             "res_lat": d["res_lat"], "res_lon": d["res_lon"]} for d in refdata.dongs()]
