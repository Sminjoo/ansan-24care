"""SQLite 저장소."""
from __future__ import annotations

import datetime as dt
import json
import os
import sqlite3
from pathlib import Path

DB_PATH = Path(os.environ.get("CARE_DB_PATH") or Path(__file__).resolve().parents[1] / "data" / "app.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  pw_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('parent','teacher','city')),
  name TEXT NOT NULL,
  phone TEXT,
  home_dong TEXT,
  facility_id INTEGER,
  demo INTEGER DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS children (
  id INTEGER PRIMARY KEY,
  parent_id INTEGER NOT NULL REFERENCES users(id),
  name TEXT NOT NULL,
  birthdate TEXT NOT NULL,
  notes TEXT DEFAULT '',
  active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS facilities (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('hub','room','timecare')),
  name TEXT NOT NULL,
  dong TEXT NOT NULL,
  lat REAL NOT NULL,
  lon REAL NOT NULL,
  address TEXT,
  phone TEXT,
  age_min_m INTEGER,
  age_max_m INTEGER,
  target TEXT,
  hours_json TEXT NOT NULL,
  staffing_json TEXT,
  per_teacher REAL DEFAULT 5,
  room_capacity INTEGER,
  fee_per_hour INTEGER DEFAULT 0,
  bookable INTEGER DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'operating',
  status_label TEXT,
  source_ref TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reservations (
  id INTEGER PRIMARY KEY,
  facility_id INTEGER NOT NULL REFERENCES facilities(id),
  child_id INTEGER NOT NULL REFERENCES children(id),
  parent_id INTEGER NOT NULL REFERENCES users(id),
  start_at TEXT NOT NULL,
  end_at TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('booked','checked_in','checked_out','cancelled','no_show')),
  fee INTEGER DEFAULT 0,
  pickup_code TEXT NOT NULL,
  note TEXT DEFAULT '',
  checkin_at TEXT,
  checkout_at TEXT,
  checkout_note TEXT,
  reminded INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  cancelled_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_res_fac_time ON reservations(facility_id, start_at);
CREATE INDEX IF NOT EXISTS ix_res_parent ON reservations(parent_id);
CREATE TABLE IF NOT EXISTS booking_failures (
  id INTEGER PRIMARY KEY,
  facility_id INTEGER NOT NULL,
  parent_id INTEGER,
  start_at TEXT NOT NULL,
  end_at TEXT NOT NULL,
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  link TEXT,
  created_at TEXT NOT NULL,
  read_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_noti_user ON notifications(user_id, created_at);
CREATE TABLE IF NOT EXISTS threads (
  id INTEGER PRIMARY KEY,
  facility_id INTEGER NOT NULL,
  parent_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(facility_id, parent_id)
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY,
  thread_id INTEGER NOT NULL REFERENCES threads(id),
  sender_id INTEGER NOT NULL REFERENCES users(id),
  body TEXT NOT NULL,
  created_at TEXT NOT NULL,
  read_by_parent INTEGER DEFAULT 0,
  read_by_facility INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS demand_requests (
  id INTEGER PRIMARY KEY,
  parent_id INTEGER,
  dong TEXT NOT NULL,
  age_group TEXT NOT NULL CHECK (age_group IN ('infant','preschool','elem')),
  slots TEXT NOT NULL,
  note TEXT DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS spaces (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL,
  name TEXT NOT NULL,
  dong TEXT NOT NULL,
  lat REAL NOT NULL,
  lon REAL NOT NULL,
  floor INTEGER,
  area REAL,
  elevator INTEGER,
  source TEXT,
  source_note TEXT,
  status TEXT NOT NULL DEFAULT 'candidate',
  checks_json TEXT DEFAULT '{}',
  memo TEXT DEFAULT '',
  facility_id INTEGER,
  updated_at TEXT,
  updated_by INTEGER
);
CREATE TABLE IF NOT EXISTS hub_plan (
  slot INTEGER PRIMARY KEY,
  year INTEGER NOT NULL,
  stcode TEXT NOT NULL,
  name TEXT NOT NULL,
  dong TEXT NOT NULL,
  lat REAL NOT NULL,
  lon REAL NOT NULL,
  memo TEXT DEFAULT '',
  updated_at TEXT,
  updated_by INTEGER
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY,
  user_id INTEGER,
  action TEXT NOT NULL,
  detail TEXT,
  created_at TEXT NOT NULL
);
"""


def now() -> dt.datetime:
    return dt.datetime.now().replace(microsecond=0)


def now_s() -> str:
    return now().isoformat(timespec="seconds")


def connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA busy_timeout=5000")
    return con


def init() -> bool:
    """스키마 생성. 새 DB면 True."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    fresh = not DB_PATH.exists()
    con = connect()
    if not os.environ.get("CARE_STATIC"):   # 브라우저(메모리 파일시스템)에서는 WAL을 쓸 수 없다
        con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    con.commit()
    con.close()
    return fresh


def rows(con, sql: str, args=()) -> list[dict]:
    return [dict(r) for r in con.execute(sql, args).fetchall()]


def one(con, sql: str, args=()) -> dict | None:
    r = con.execute(sql, args).fetchone()
    return dict(r) if r else None


def get_setting(con, key: str, default=None):
    r = one(con, "SELECT value FROM settings WHERE key=?", (key,))
    return json.loads(r["value"]) if r else default


def set_setting(con, key: str, value) -> None:
    con.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, json.dumps(value, ensure_ascii=False)))


def audit(con, user_id, action: str, detail) -> None:
    con.execute("INSERT INTO audit_log(user_id,action,detail,created_at) VALUES(?,?,?,?)",
                (user_id, action, json.dumps(detail, ensure_ascii=False), now_s()))
