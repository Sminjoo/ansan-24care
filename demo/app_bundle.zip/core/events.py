"""사용자별 실시간 이벤트(Server-Sent Events) 버스."""
from __future__ import annotations

import json
import queue
import threading

_lock = threading.Lock()
_subs: dict[int, list[queue.Queue]] = {}


def subscribe(user_id: int) -> queue.Queue:
    q: queue.Queue = queue.Queue(maxsize=200)
    with _lock:
        _subs.setdefault(user_id, []).append(q)
    return q


def unsubscribe(user_id: int, q: queue.Queue) -> None:
    with _lock:
        lst = _subs.get(user_id, [])
        if q in lst:
            lst.remove(q)


def publish(user_id: int, kind: str, data: dict) -> None:
    payload = json.dumps({"type": kind, "data": data}, ensure_ascii=False)
    with _lock:
        targets = list(_subs.get(user_id, []))
    for q in targets:
        try:
            q.put_nowait(payload)
        except queue.Full:
            pass


def online_users() -> int:
    with _lock:
        return sum(1 for v in _subs.values() if v)
